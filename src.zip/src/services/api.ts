import {
  LockoutState,
  PriceAlert,
  Product,
  ScrapingJob,
  ScrapingLog,
  SearchFilters,
  SearchHistoryItem,
  SiteSelectorConfig,
  User,
  VendorId
} from '../types';
import { formatSafeErrorMessage, sanitizeSearchQuery } from '../utils/security';
import { Storage } from './storage';

// Base API URL for backend integration
export const API_BASE_URL: string = (import.meta as any).env?.VITE_API_BASE_URL || '';
export const USE_MOCK: boolean = !API_BASE_URL || (import.meta as any).env?.VITE_USE_MOCK === 'true';

// Delay helper for realistic asynchronous UI feel
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const api = {
  auth: {
    async login(email: string, pass: string): Promise<{ user: User; lockout: LockoutState }> {
      await delay(350);

      // Check current lockout status
      const lockout = Storage.getLockoutState();
      if (lockout.isLocked) {
        throw new Error('Account locked due to 5 consecutive failed attempts. Please wait before retrying.');
      }

      // Demo login verification
      const users = Storage.getRegisteredUsers();
      const matched = users.find(u => u.email.toLowerCase() === email.toLowerCase());

      // Simple mock password rules: 'admin123' for admin, 'user123' or any 6+ chars for standard user
      const isPasswordValid =
        (email === 'admin@dealpulse.com' && pass === 'admin123') ||
        (email === 'user@example.com' && pass === 'user123') ||
        (matched && pass.length >= 6);

      if (!matched || !isPasswordValid) {
        const newLockout = Storage.recordFailedLoginAttempt();
        if (newLockout.isLocked) {
          throw new Error('Account locked! You have failed 5 login attempts. Please wait 60 seconds.');
        }
        throw new Error(`Invalid credentials. Attempt ${newLockout.failedAttempts} of 5 before lockout.`);
      }

      // Successful login
      Storage.resetLockout();
      Storage.setUser(matched);
      return { user: matched, lockout: Storage.getLockoutState() };
    },

    async register(name: string, email: string, _pass: string, role: 'user' | 'admin' = 'user'): Promise<User> {
      await delay(400);
      const existing = Storage.getRegisteredUsers().find(u => u.email.toLowerCase() === email.toLowerCase());
      if (existing) {
        throw new Error('An account with this email already exists.');
      }

      const newUser: User = {
        id: 'usr-' + Date.now(),
        name: name.trim(),
        email: email.trim().toLowerCase(),
        role,
        createdAt: new Date().toISOString()
      };

      Storage.addRegisteredUser(newUser);
      Storage.setUser(newUser);
      Storage.resetLockout();
      return newUser;
    },

    async logout(): Promise<void> {
      await delay(150);
      Storage.setUser(null);
    },

    getCurrentUser(): User | null {
      return Storage.getUser();
    },

    getLockoutState(): LockoutState {
      return Storage.getLockoutState();
    },

    simulateFiveFailedAttempts(): LockoutState {
      // Direct helper for demo / QA testing
      const lockedState: LockoutState = {
        failedAttempts: 5,
        isLocked: true,
        lockedUntil: Date.now() + 60 * 1000
      };
      Storage.setLockoutState(lockedState);
      return lockedState;
    },

    resetLockout(): LockoutState {
      Storage.resetLockout();
      return Storage.getLockoutState();
    }
  },

  products: {
    async search(filters: SearchFilters): Promise<{
      products: Product[];
      totalCount: number;
      sanitizationNotice?: string;
    }> {
      await delay(300);

      // Validate and sanitize search query
      const sanitizedResult = sanitizeSearchQuery(filters.query);
      if (!sanitizedResult.isValid) {
        throw new Error(sanitizedResult.errorMessage || 'Invalid search query.');
      }

      try {
        const allProducts = Storage.getProducts();
        const q = sanitizedResult.sanitized.toLowerCase();

        // Filter products
        let filtered = allProducts.filter(p => {
          // Query matching on title, brand, category, description, and specs
          const matchesQuery =
            p.title.toLowerCase().includes(q) ||
            p.brand.toLowerCase().includes(q) ||
            p.category.toLowerCase().includes(q) ||
            p.description.toLowerCase().includes(q) ||
            Object.values(p.specs).some(v => v.toLowerCase().includes(q));

          if (!matchesQuery) return false;

          // Category filter
          if (filters.category && filters.category !== 'All' && p.category !== filters.category) {
            return false;
          }

          // Brand filter
          if (filters.brands && filters.brands.length > 0 && !filters.brands.includes(p.brand)) {
            return false;
          }

          // Price filter
          if (filters.maxPrice && p.cheapestPrice > filters.maxPrice) {
            return false;
          }
          if (filters.minPrice && p.cheapestPrice < filters.minPrice) {
            return false;
          }

          // Rating filter
          if (filters.minRating && p.averageRating < filters.minRating) {
            return false;
          }

          // Vendor filter (must have at least one active listing from selected vendors)
          if (filters.vendors && filters.vendors.length > 0) {
            const hasVendor = p.listings.some(l => filters.vendors.includes(l.vendor) && (!filters.inStockOnly || l.inStock));
            if (!hasVendor) return false;
          }

          // In-stock only
          if (filters.inStockOnly) {
            const hasStock = p.listings.some(l => l.inStock);
            if (!hasStock) return false;
          }

          return true;
        });

        // Sort results
        switch (filters.sortBy) {
          case 'price_asc':
            filtered.sort((a, b) => a.cheapestPrice - b.cheapestPrice);
            break;
          case 'price_desc':
            filtered.sort((a, b) => b.cheapestPrice - a.cheapestPrice);
            break;
          case 'rating_desc':
            filtered.sort((a, b) => b.averageRating - a.averageRating);
            break;
          case 'savings_desc':
            filtered.sort((a, b) => b.savingsAmount - a.savingsAmount);
            break;
          default:
            filtered.sort((a, b) => a.cheapestPrice - b.cheapestPrice);
        }

        // Record in search history automatically
        if (filtered.length > 0) {
          Storage.addSearchHistoryItem({
            query: sanitizedResult.sanitized,
            resultCount: filtered.length,
            cheapestPriceFound: filtered[0].cheapestPrice,
            bestVendor: filtered[0].cheapestVendor,
            savedFilters: filters
          });
        }

        return {
          products: filtered,
          totalCount: filtered.length,
          sanitizationNotice: sanitizedResult.hasSecurityRisk ? sanitizedResult.threatDetails : undefined
        };
      } catch (err) {
        // Enforce requirement: gracefully handle errors without exposing database text
        throw new Error(formatSafeErrorMessage(err));
      }
    },

    async getAll(): Promise<Product[]> {
      await delay(150);
      return Storage.getProducts();
    },

    async getById(id: string): Promise<Product | null> {
      await delay(150);
      const all = Storage.getProducts();
      return all.find(p => p.id === id) || null;
    }
  },

  history: {
    async getAll(): Promise<SearchHistoryItem[]> {
      await delay(100);
      return Storage.getSearchHistory();
    },
    async delete(id: string): Promise<void> {
      Storage.removeSearchHistoryItem(id);
    },
    async clear(): Promise<void> {
      Storage.clearSearchHistory();
    }
  },

  alerts: {
    async getAll(): Promise<PriceAlert[]> {
      await delay(120);
      return Storage.getPriceAlerts();
    },
    async create(alertData: Omit<PriceAlert, 'id' | 'createdAt' | 'status' | 'lastChecked'>): Promise<PriceAlert> {
      await delay(200);
      return Storage.addPriceAlert(alertData);
    },
    async delete(id: string): Promise<void> {
      Storage.removePriceAlert(id);
    },
    async toggleStatus(id: string): Promise<void> {
      Storage.togglePriceAlertStatus(id);
    },
    async simulateTrigger(id: string): Promise<PriceAlert | null> {
      const alerts = Storage.getPriceAlerts();
      const target = alerts.find(a => a.id === id);
      if (!target) return null;

      // Drop current price below target to trigger
      target.status = 'triggered';
      target.currentLowestPrice = Math.max(10, Math.floor(target.targetPrice * 0.95));
      target.lastChecked = new Date().toISOString();
      localStorage.setItem('cpf_price_alerts', JSON.stringify(alerts));
      return target;
    }
  },

  admin: {
    async getScrapingJobs(): Promise<ScrapingJob[]> {
      await delay(150);
      return Storage.getScrapingJobs();
    },

    async triggerScrape(vendor: VendorId): Promise<ScrapingJob> {
      await delay(400);
      const jobs = Storage.getScrapingJobs();
      const existing = jobs.find(j => j.vendor === vendor);

      const updatedJob: ScrapingJob = {
        id: existing?.id || 'job-' + vendor + '-' + Date.now(),
        vendor,
        vendorName: vendor === 'amazon' ? 'Amazon India' : vendor === 'flipkart' ? 'Flipkart' : 'BigBasket',
        targetCategory: existing?.targetCategory || 'All Catalogs',
        status: 'running',
        itemsScraped: 0,
        retryCount: 0,
        maxRetries: 3,
        startedAt: new Date().toISOString(),
        durationSec: 1
      };

      Storage.updateScrapingJob(updatedJob);
      Storage.addScrapingLog({
        jobId: updatedJob.id,
        vendor,
        level: 'INFO',
        message: `Manual scraping job started by admin for ${updatedJob.vendorName}. Worker pool spun up.`
      });

      return updatedJob;
    },

    async completeScrapeSimulation(jobId: string, itemsScraped: number): Promise<void> {
      const jobs = Storage.getScrapingJobs();
      const job = jobs.find(j => j.id === jobId);
      if (job) {
        job.status = 'completed';
        job.itemsScraped = itemsScraped;
        job.durationSec = 45;
        Storage.updateScrapingJob(job);
        Storage.addScrapingLog({
          jobId,
          vendor: job.vendor,
          level: 'SUCCESS',
          message: `Scraping cycle completed successfully. Ingested ${itemsScraped} updated price records.`
        });
      }
    },

    async getLogs(): Promise<ScrapingLog[]> {
      await delay(100);
      return Storage.getScrapingLogs();
    },

    async clearLogs(): Promise<void> {
      Storage.clearScrapingLogs();
    },

    async getSiteConfigs(): Promise<SiteSelectorConfig[]> {
      await delay(120);
      return Storage.getSiteConfigs();
    },

    async updateSiteConfig(config: SiteSelectorConfig): Promise<SiteSelectorConfig> {
      await delay(300);
      const updated = {
        ...config,
        lastUpdated: new Date().toISOString().replace('T', ' ').substring(0, 19),
        updatedBy: Storage.getUser()?.email || 'admin@dealpulse.com'
      };
      Storage.updateSiteConfig(updated);
      Storage.addScrapingLog({
        jobId: 'config-change',
        vendor: config.vendor,
        level: 'INFO',
        message: `Selectors updated for ${config.vendorName} by ${updated.updatedBy}. CSS rules recompiled.`,
        selectorTested: config.selectors.price
      });
      return updated;
    },

    testSelectorSimulation(selector: string, sampleHtml: string): { matches: number; sampleExtract: string } {
      if (!selector || selector.trim().length === 0) {
        return { matches: 0, sampleExtract: 'Selector cannot be empty' };
      }
      try {
        const parser = new DOMParser();
        const doc = parser.parseFromString(sampleHtml || '<div></div>', 'text/html');
        const elements = doc.querySelectorAll(selector);
        const sampleExtract = elements.length > 0 ? elements[0].textContent?.trim() || elements[0].outerHTML : 'No elements matched in DOM preview';
        return {
          matches: elements.length,
          sampleExtract
        };
      } catch (e) {
        return {
          matches: 0,
          sampleExtract: 'Syntax error in CSS/XPath query: ' + (e as Error).message
        };
      }
    }
  }
};
