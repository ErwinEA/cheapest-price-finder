import { Product, ScrapingJob, ScrapingLog, SiteSelectorConfig, User } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-iphone-15',
    title: 'Apple iPhone 15 (128 GB) - Black',
    category: 'Smartphones',
    brand: 'Apple',
    imageUrl: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=600&auto=format&fit=crop&q=80',
    description: 'Dynamic Island, 48MP main camera, USB-C, A16 Bionic chip, durable color-infused glass and aluminum design.',
    specs: {
      'Storage': '128 GB',
      'Display': '6.1-inch Super Retina XDR',
      'Processor': 'A16 Bionic chip',
      'Camera': '48MP Main + 12MP Ultra Wide'
    },
    cheapestVendor: 'flipkart',
    cheapestPrice: 65999,
    highestPrice: 71999,
    savingsAmount: 6000,
    savingsPercent: 8.3,
    averageRating: 4.6,
    listings: [
      {
        id: 'list-ip15-flipkart',
        vendor: 'flipkart',
        price: 65999,
        originalPrice: 79900,
        discountPercent: 17,
        productUrl: 'https://www.flipkart.com/apple-iphone-15-black-128-gb/p/itm6ac6485515ae4',
        inStock: true,
        rating: 4.6,
        ratingsCount: 28410,
        deliveryDays: 'Tomorrow, by 2 PM',
        deliveryFee: 0,
        seller: 'SuperComNet Retail',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 15).toISOString()
      },
      {
        id: 'list-ip15-amazon',
        vendor: 'amazon',
        price: 69999,
        originalPrice: 79900,
        discountPercent: 12,
        productUrl: 'https://www.amazon.in/Apple-iPhone-15-128-GB/dp/B0CHX1W1XY',
        inStock: true,
        rating: 4.5,
        ratingsCount: 42100,
        deliveryDays: 'Tomorrow, by 11 AM (Prime)',
        deliveryFee: 0,
        seller: 'Appario Retail Pvt Ltd',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 8).toISOString()
      },
      {
        id: 'list-ip15-bigbasket',
        vendor: 'bigbasket',
        price: 71999,
        originalPrice: 79900,
        discountPercent: 10,
        productUrl: 'https://www.bigbasket.com/pd/electronics/apple-iphone-15-128gb-black',
        inStock: true,
        rating: 4.3,
        ratingsCount: 412,
        deliveryDays: 'Today, in 30 mins (BB Now)',
        deliveryFee: 49,
        seller: 'Innovative Retail Ltd',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 30).toISOString()
      }
    ],
    priceHistory: [
      { date: 'Oct 01', amazon: 74999, flipkart: 73999, bigbasket: 75999 },
      { date: 'Oct 07', amazon: 72999, flipkart: 71499, bigbasket: 74999 },
      { date: 'Oct 14', amazon: 71999, flipkart: 69999, bigbasket: 73999 },
      { date: 'Oct 21', amazon: 70499, flipkart: 67999, bigbasket: 72999 },
      { date: 'Oct 25', amazon: 69999, flipkart: 66499, bigbasket: 71999 },
      { date: 'Oct 28', amazon: 69999, flipkart: 65999, bigbasket: 71999 }
    ]
  },
  {
    id: 'prod-sony-wh1000xm5',
    title: 'Sony WH-1000XM5 Wireless Active Noise Cancelling Headphones',
    category: 'Audio',
    brand: 'Sony',
    imageUrl: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=600&auto=format&fit=crop&q=80',
    description: 'Industry leading noise cancellation with two processors and 8 microphones. Up to 30 hours battery life with quick charging.',
    specs: {
      'Battery Life': '30 Hours',
      'Noise Cancelling': 'Dual Processor V1 + HD QN1',
      'Connectivity': 'Bluetooth 5.2, Multipoint',
      'Weight': '250 grams'
    },
    cheapestVendor: 'amazon',
    cheapestPrice: 26990,
    highestPrice: 29990,
    savingsAmount: 3000,
    savingsPercent: 10,
    averageRating: 4.7,
    listings: [
      {
        id: 'list-sony-amazon',
        vendor: 'amazon',
        price: 26990,
        originalPrice: 34990,
        discountPercent: 23,
        productUrl: 'https://www.amazon.in/Sony-WH-1000XM5-Cancelling-Headphones-Call-Black/dp/B09XS7JWHH',
        inStock: true,
        rating: 4.7,
        ratingsCount: 16820,
        deliveryDays: 'Tomorrow, by 10 AM (Prime)',
        deliveryFee: 0,
        seller: 'Electronics SuperStore',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 12).toISOString()
      },
      {
        id: 'list-sony-flipkart',
        vendor: 'flipkart',
        price: 28990,
        originalPrice: 34990,
        discountPercent: 17,
        productUrl: 'https://www.flipkart.com/sony-wh-1000xm5-bluetooth-headset/p/itm5347b2c0e86b0',
        inStock: true,
        rating: 4.6,
        ratingsCount: 8430,
        deliveryDays: '2 Days, by 5 PM',
        deliveryFee: 40,
        seller: 'OmniTech Gadgets',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 25).toISOString()
      },
      {
        id: 'list-sony-bigbasket',
        vendor: 'bigbasket',
        price: 29990,
        originalPrice: 34990,
        discountPercent: 14,
        productUrl: 'https://www.bigbasket.com/pd/electronics/sony-wh1000xm5-anc-black',
        inStock: false,
        rating: 4.5,
        ratingsCount: 88,
        deliveryDays: 'Out of Stock',
        deliveryFee: 0,
        seller: 'BB Electronics Hub',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 45).toISOString()
      }
    ],
    priceHistory: [
      { date: 'Oct 01', amazon: 29990, flipkart: 31990, bigbasket: 32990 },
      { date: 'Oct 07', amazon: 28990, flipkart: 30490, bigbasket: 31990 },
      { date: 'Oct 14', amazon: 27990, flipkart: 29990, bigbasket: 31990 },
      { date: 'Oct 21', amazon: 27490, flipkart: 29490, bigbasket: 30990 },
      { date: 'Oct 25', amazon: 26990, flipkart: 28990, bigbasket: 29990 },
      { date: 'Oct 28', amazon: 26990, flipkart: 28990, bigbasket: 29990 }
    ]
  },
  {
    id: 'prod-aashirvaad-atta',
    title: 'Aashirvaad Superior MP Sharbati Whole Wheat Atta 5kg',
    category: 'Groceries & Staples',
    brand: 'Aashirvaad',
    imageUrl: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=600&auto=format&fit=crop&q=80',
    description: '100% pure Sharbati wheat grains harvested directly from Madhya Pradesh. Delivers softer, fluffier, and nutritious rotis.',
    specs: {
      'Net Quantity': '5 kg',
      'Ingredient Type': 'Vegetarian',
      'Origin': 'Sehore, Madhya Pradesh',
      'Shelf Life': '6 Months'
    },
    cheapestVendor: 'bigbasket',
    cheapestPrice: 319,
    highestPrice: 365,
    savingsAmount: 46,
    savingsPercent: 12.6,
    averageRating: 4.8,
    listings: [
      {
        id: 'list-atta-bigbasket',
        vendor: 'bigbasket',
        price: 319,
        originalPrice: 385,
        discountPercent: 17,
        productUrl: 'https://www.bigbasket.com/pd/126906/aashirvaad-sharbati-atta-5-kg',
        inStock: true,
        rating: 4.8,
        ratingsCount: 56210,
        deliveryDays: 'Today, within 2 hours',
        deliveryFee: 0,
        seller: 'Innovative Foodworks',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 5).toISOString()
      },
      {
        id: 'list-atta-amazon',
        vendor: 'amazon',
        price: 345,
        originalPrice: 385,
        discountPercent: 10,
        productUrl: 'https://www.amazon.in/Aashirvaad-Superior-MP-Atta-5kg/dp/B00TYENWTI',
        inStock: true,
        rating: 4.6,
        ratingsCount: 34100,
        deliveryDays: 'Tomorrow (Amazon Fresh)',
        deliveryFee: 30,
        seller: 'Amazon Fresh Direct',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 18).toISOString()
      },
      {
        id: 'list-atta-flipkart',
        vendor: 'flipkart',
        price: 365,
        originalPrice: 385,
        discountPercent: 5,
        productUrl: 'https://www.flipkart.com/aashirvaad-select-sharbati-atta-5-kg/p/itme9zvyz8kbhkgk',
        inStock: true,
        rating: 4.5,
        ratingsCount: 12890,
        deliveryDays: 'Tomorrow (Flipkart Grocery)',
        deliveryFee: 35,
        seller: 'Flipkart Grocery Hub',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 22).toISOString()
      }
    ],
    priceHistory: [
      { date: 'Oct 01', amazon: 360, flipkart: 375, bigbasket: 335 },
      { date: 'Oct 07', amazon: 355, flipkart: 370, bigbasket: 329 },
      { date: 'Oct 14', amazon: 350, flipkart: 370, bigbasket: 325 },
      { date: 'Oct 21', amazon: 348, flipkart: 365, bigbasket: 320 },
      { date: 'Oct 25', amazon: 345, flipkart: 365, bigbasket: 319 },
      { date: 'Oct 28', amazon: 345, flipkart: 365, bigbasket: 319 }
    ]
  },
  {
    id: 'prod-fortune-oil',
    title: 'Fortune Sunlite Refined Sunflower Oil Jar 5L',
    category: 'Groceries & Staples',
    brand: 'Fortune',
    imageUrl: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=600&auto=format&fit=crop&q=80',
    description: 'Enriched with Vitamin A and D. Light and healthy oil with high smoke point for everyday Indian cooking and frying.',
    specs: {
      'Volume': '5 Litres',
      'Type': 'Refined Sunflower Oil',
      'Container': 'Can / Jar with handle',
      'Nutrients': 'Fortified with Vitamins A, D, E'
    },
    cheapestVendor: 'bigbasket',
    cheapestPrice: 649,
    highestPrice: 720,
    savingsAmount: 71,
    savingsPercent: 9.8,
    averageRating: 4.6,
    listings: [
      {
        id: 'list-oil-bigbasket',
        vendor: 'bigbasket',
        price: 649,
        originalPrice: 850,
        discountPercent: 24,
        productUrl: 'https://www.bigbasket.com/pd/274148/fortune-sunlite-sunflower-oil-5-l',
        inStock: true,
        rating: 4.7,
        ratingsCount: 38900,
        deliveryDays: 'Today, by 4 PM',
        deliveryFee: 0,
        seller: 'BB Wholesale Direct',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 10).toISOString()
      },
      {
        id: 'list-oil-flipkart',
        vendor: 'flipkart',
        price: 695,
        originalPrice: 850,
        discountPercent: 18,
        productUrl: 'https://www.flipkart.com/fortune-sunlite-refined-sunflower-oil-can-5-l/p/itm5ea35d55ad5eb',
        inStock: true,
        rating: 4.5,
        ratingsCount: 14200,
        deliveryDays: 'Tomorrow',
        deliveryFee: 29,
        seller: 'Flipkart Mart',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 35).toISOString()
      },
      {
        id: 'list-oil-amazon',
        vendor: 'amazon',
        price: 720,
        originalPrice: 850,
        discountPercent: 15,
        productUrl: 'https://www.amazon.in/Fortune-Sunlite-Refined-Sunflower-Can/dp/B00TYEQ2H2',
        inStock: true,
        rating: 4.6,
        ratingsCount: 22100,
        deliveryDays: 'Tomorrow, by 8 PM',
        deliveryFee: 0,
        seller: 'Cloudtail Essentials',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 15).toISOString()
      }
    ],
    priceHistory: [
      { date: 'Oct 01', amazon: 749, flipkart: 730, bigbasket: 679 },
      { date: 'Oct 07', amazon: 740, flipkart: 715, bigbasket: 669 },
      { date: 'Oct 14', amazon: 730, flipkart: 710, bigbasket: 659 },
      { date: 'Oct 21', amazon: 725, flipkart: 700, bigbasket: 652 },
      { date: 'Oct 25', amazon: 720, flipkart: 698, bigbasket: 649 },
      { date: 'Oct 28', amazon: 720, flipkart: 695, bigbasket: 649 }
    ]
  },
  {
    id: 'prod-samsung-s24-ultra',
    title: 'Samsung Galaxy S24 Ultra 5G (Titanium Gray, 256 GB)',
    category: 'Smartphones',
    brand: 'Samsung',
    imageUrl: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=600&auto=format&fit=crop&q=80',
    description: 'Galaxy AI with Circle to Search, 200MP camera with ProVisual engine, titanium exterior with S Pen included.',
    specs: {
      'Storage': '256 GB / 12 GB RAM',
      'Processor': 'Snapdragon 8 Gen 3 for Galaxy',
      'Display': '6.8-inch Dynamic AMOLED 2X 120Hz',
      'Battery': '5000 mAh'
    },
    cheapestVendor: 'flipkart',
    cheapestPrice: 117499,
    highestPrice: 124999,
    savingsAmount: 7500,
    savingsPercent: 6,
    averageRating: 4.8,
    listings: [
      {
        id: 'list-s24-flipkart',
        vendor: 'flipkart',
        price: 117499,
        originalPrice: 134999,
        discountPercent: 13,
        productUrl: 'https://www.flipkart.com/samsung-galaxy-s24-ultra-5g-titanium-gray-256-gb/p/itmd572d4c09d57a',
        inStock: true,
        rating: 4.8,
        ratingsCount: 14200,
        deliveryDays: 'Tomorrow, by 1 PM',
        deliveryFee: 0,
        seller: 'IndiFlash Electronics',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 18).toISOString()
      },
      {
        id: 'list-s24-amazon',
        vendor: 'amazon',
        price: 119999,
        originalPrice: 134999,
        discountPercent: 11,
        productUrl: 'https://www.amazon.in/Samsung-Galaxy-Ultra-Titanium-Storage/dp/B0CS5XW1Q3',
        inStock: true,
        rating: 4.7,
        ratingsCount: 19800,
        deliveryDays: 'Tomorrow, by 11 AM',
        deliveryFee: 0,
        seller: 'STPL Exclusive Online',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 9).toISOString()
      },
      {
        id: 'list-s24-bigbasket',
        vendor: 'bigbasket',
        price: 124999,
        originalPrice: 134999,
        discountPercent: 7,
        productUrl: 'https://www.bigbasket.com/pd/electronics/samsung-galaxy-s24-ultra-256gb',
        inStock: false,
        rating: 4.4,
        ratingsCount: 110,
        deliveryDays: 'Out of stock in your pincode',
        deliveryFee: 0,
        seller: 'Innovative Gadgets Hub',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 50).toISOString()
      }
    ],
    priceHistory: [
      { date: 'Oct 01', amazon: 124999, flipkart: 122999, bigbasket: 127999 },
      { date: 'Oct 07', amazon: 122999, flipkart: 120999, bigbasket: 126499 },
      { date: 'Oct 14', amazon: 121499, flipkart: 119499, bigbasket: 125999 },
      { date: 'Oct 21', amazon: 120499, flipkart: 118499, bigbasket: 124999 },
      { date: 'Oct 25', amazon: 119999, flipkart: 117999, bigbasket: 124999 },
      { date: 'Oct 28', amazon: 119999, flipkart: 117499, bigbasket: 124999 }
    ]
  },
  {
    id: 'prod-tata-tea-gold',
    title: 'Tata Tea Gold Leaf Tea Pouch 1kg',
    category: 'Groceries & Staples',
    brand: 'Tata Tea',
    imageUrl: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=600&auto=format&fit=crop&q=80',
    description: 'Unique blend of gently rolled aromatic long leaves with Assam CTC tea for irresistible aroma and rich taste.',
    specs: {
      'Net Weight': '1 kg',
      'Format': 'Loose Leaf & CTC Granules',
      'Caffeine Content': 'Caffeinated',
      'Roast': 'Medium'
    },
    cheapestVendor: 'bigbasket',
    cheapestPrice: 480,
    highestPrice: 535,
    savingsAmount: 55,
    savingsPercent: 10.3,
    averageRating: 4.7,
    listings: [
      {
        id: 'list-tea-bigbasket',
        vendor: 'bigbasket',
        price: 480,
        originalPrice: 620,
        discountPercent: 23,
        productUrl: 'https://www.bigbasket.com/pd/266579/tata-tea-gold-1-kg',
        inStock: true,
        rating: 4.7,
        ratingsCount: 44100,
        deliveryDays: 'Today, in 30 mins',
        deliveryFee: 0,
        seller: 'BB SuperDaily Direct',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 11).toISOString()
      },
      {
        id: 'list-tea-flipkart',
        vendor: 'flipkart',
        price: 510,
        originalPrice: 620,
        discountPercent: 18,
        productUrl: 'https://www.flipkart.com/tata-tea-gold-leaf-1-kg/p/itm5a812ba3c14a5',
        inStock: true,
        rating: 4.6,
        ratingsCount: 22800,
        deliveryDays: 'Tomorrow, by 12 PM',
        deliveryFee: 20,
        seller: 'FMCG Mart Online',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 20).toISOString()
      },
      {
        id: 'list-tea-amazon',
        vendor: 'amazon',
        price: 535,
        originalPrice: 620,
        discountPercent: 14,
        productUrl: 'https://www.amazon.in/Tata-Tea-Gold-1kg/dp/B00TYEO4K0',
        inStock: true,
        rating: 4.6,
        ratingsCount: 31200,
        deliveryDays: 'Tomorrow, by 8 PM',
        deliveryFee: 40,
        seller: 'Amazon Pantry',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 14).toISOString()
      }
    ],
    priceHistory: [
      { date: 'Oct 01', amazon: 550, flipkart: 535, bigbasket: 505 },
      { date: 'Oct 07', amazon: 545, flipkart: 525, bigbasket: 495 },
      { date: 'Oct 14', amazon: 540, flipkart: 520, bigbasket: 490 },
      { date: 'Oct 21', amazon: 535, flipkart: 515, bigbasket: 485 },
      { date: 'Oct 25', amazon: 535, flipkart: 510, bigbasket: 480 },
      { date: 'Oct 28', amazon: 535, flipkart: 510, bigbasket: 480 }
    ]
  },
  {
    id: 'prod-boat-airdopes',
    title: 'Boat Airdopes 141 ANC True Wireless Earbuds',
    category: 'Audio',
    brand: 'Boat',
    imageUrl: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=600&auto=format&fit=crop&q=80',
    description: 'Up to 32dB Active Noise Cancellation, 42 hours total playtime, Beast mode low latency for gaming, ENx clear voice calls.',
    specs: {
      'Playtime': '42 Hours Total',
      'ANC': 'Up to 32 dB',
      'Low Latency': '50ms Beast Mode',
      'Water Resistance': 'IPX5'
    },
    cheapestVendor: 'flipkart',
    cheapestPrice: 1199,
    highestPrice: 1499,
    savingsAmount: 300,
    savingsPercent: 20,
    averageRating: 4.3,
    listings: [
      {
        id: 'list-boat-flipkart',
        vendor: 'flipkart',
        price: 1199,
        originalPrice: 4490,
        discountPercent: 73,
        productUrl: 'https://www.flipkart.com/boat-airdopes-141-anc-32-db-bluetooth-headset/p/itm21b069fafe58a',
        inStock: true,
        rating: 4.4,
        ratingsCount: 78500,
        deliveryDays: 'Tomorrow, by 6 PM',
        deliveryFee: 0,
        seller: 'RetailNet Tech',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 12).toISOString()
      },
      {
        id: 'list-boat-amazon',
        vendor: 'amazon',
        price: 1299,
        originalPrice: 4490,
        discountPercent: 71,
        productUrl: 'https://www.amazon.in/boAt-Airdopes-141-ANC-Cancellation/dp/B0CC39257H',
        inStock: true,
        rating: 4.2,
        ratingsCount: 112000,
        deliveryDays: 'Tomorrow, by 11 AM',
        deliveryFee: 0,
        seller: 'Imagine Marketing Pvt Ltd',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 19).toISOString()
      },
      {
        id: 'list-boat-bigbasket',
        vendor: 'bigbasket',
        price: 1499,
        originalPrice: 4490,
        discountPercent: 66,
        productUrl: 'https://www.bigbasket.com/pd/electronics/boat-airdopes-141-anc-earbuds',
        inStock: true,
        rating: 4.1,
        ratingsCount: 320,
        deliveryDays: 'Today, within 2 hours',
        deliveryFee: 29,
        seller: 'BB Tech Fast',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 40).toISOString()
      }
    ],
    priceHistory: [
      { date: 'Oct 01', amazon: 1499, flipkart: 1399, bigbasket: 1599 },
      { date: 'Oct 07', amazon: 1399, flipkart: 1299, bigbasket: 1549 },
      { date: 'Oct 14', amazon: 1349, flipkart: 1249, bigbasket: 1549 },
      { date: 'Oct 21', amazon: 1299, flipkart: 1249, bigbasket: 1499 },
      { date: 'Oct 25', amazon: 1299, flipkart: 1199, bigbasket: 1499 },
      { date: 'Oct 28', amazon: 1299, flipkart: 1199, bigbasket: 1499 }
    ]
  },
  {
    id: 'prod-surf-excel-liquid',
    title: 'Surf Excel Matic Front Load Liquid Detergent Pouch 4L',
    category: 'Household',
    brand: 'Surf Excel',
    imageUrl: 'https://images.unsplash.com/photo-1610557892470-55d9e80c0bce?w=600&auto=format&fit=crop&q=80',
    description: 'Powerful stain removal formula specifically engineered for front load washing machines. Dissolves completely without residue.',
    specs: {
      'Volume': '4 Litres',
      'Format': 'Concentrated Liquid Detergent',
      'Suitability': 'Front Load Machines',
      'Fragrance': 'Fresh Breeze'
    },
    cheapestVendor: 'bigbasket',
    cheapestPrice: 799,
    highestPrice: 915,
    savingsAmount: 116,
    savingsPercent: 12.7,
    averageRating: 4.8,
    listings: [
      {
        id: 'list-surf-bigbasket',
        vendor: 'bigbasket',
        price: 799,
        originalPrice: 1050,
        discountPercent: 24,
        productUrl: 'https://www.bigbasket.com/pd/40198424/surf-excel-matic-front-load-liquid-detergent-4-l',
        inStock: true,
        rating: 4.8,
        ratingsCount: 62400,
        deliveryDays: 'Today, in 45 mins',
        deliveryFee: 0,
        seller: 'Innovative Retail Ltd',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 7).toISOString()
      },
      {
        id: 'list-surf-amazon',
        vendor: 'amazon',
        price: 885,
        originalPrice: 1050,
        discountPercent: 16,
        productUrl: 'https://www.amazon.in/Surf-Excel-Matic-Liquid-Detergent/dp/B0852P8G7R',
        inStock: true,
        rating: 4.7,
        ratingsCount: 45800,
        deliveryDays: 'Tomorrow, by 1 PM',
        deliveryFee: 0,
        seller: 'Cloudtail Retail Store',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 16).toISOString()
      },
      {
        id: 'list-surf-flipkart',
        vendor: 'flipkart',
        price: 915,
        originalPrice: 1050,
        discountPercent: 13,
        productUrl: 'https://www.flipkart.com/surf-excel-matic-front-load-liquid-detergent-4-l/p/itmbf49d9c824cbf',
        inStock: true,
        rating: 4.6,
        ratingsCount: 19400,
        deliveryDays: 'Tomorrow, by 4 PM',
        deliveryFee: 25,
        seller: 'Grocery Prime India',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 27).toISOString()
      }
    ],
    priceHistory: [
      { date: 'Oct 01', amazon: 920, flipkart: 940, bigbasket: 849 },
      { date: 'Oct 07', amazon: 910, flipkart: 935, bigbasket: 829 },
      { date: 'Oct 14', amazon: 899, flipkart: 925, bigbasket: 819 },
      { date: 'Oct 21', amazon: 890, flipkart: 920, bigbasket: 809 },
      { date: 'Oct 25', amazon: 885, flipkart: 915, bigbasket: 799 },
      { date: 'Oct 28', amazon: 885, flipkart: 915, bigbasket: 799 }
    ]
  },
  {
    id: 'prod-logitech-mx-master-3s',
    title: 'Logitech MX Master 3S Wireless Performance Mouse',
    category: 'Accessories & PC',
    brand: 'Logitech',
    imageUrl: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=600&auto=format&fit=crop&q=80',
    description: 'Quiet clicks, 8K DPI track-on-glass sensor, MagSpeed electromagnetic scrolling, USB-C fast charging, ergonomic design.',
    specs: {
      'Sensor': 'Darkfield 8000 DPI',
      'Battery': 'Up to 70 days per charge',
      'Scroll Wheel': 'MagSpeed SmartShift',
      'Connectivity': 'Bluetooth Low Energy & Logi Bolt'
    },
    cheapestVendor: 'amazon',
    cheapestPrice: 8495,
    highestPrice: 9499,
    savingsAmount: 1004,
    savingsPercent: 10.6,
    averageRating: 4.8,
    listings: [
      {
        id: 'list-logi-amazon',
        vendor: 'amazon',
        price: 8495,
        originalPrice: 10995,
        discountPercent: 23,
        productUrl: 'https://www.amazon.in/Logitech-Performance-Wireless-Ultra-Fast-Customization/dp/B09HM94VDS',
        inStock: true,
        rating: 4.8,
        ratingsCount: 14200,
        deliveryDays: 'Tomorrow, by 10 AM',
        deliveryFee: 0,
        seller: 'Appario Retail Pvt Ltd',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 14).toISOString()
      },
      {
        id: 'list-logi-flipkart',
        vendor: 'flipkart',
        price: 9299,
        originalPrice: 10995,
        discountPercent: 15,
        productUrl: 'https://www.flipkart.com/logitech-mx-master-3s-wireless-optical-mouse/p/itm5424cf3b5ebca',
        inStock: true,
        rating: 4.7,
        ratingsCount: 6540,
        deliveryDays: '2 Days, by 2 PM',
        deliveryFee: 0,
        seller: 'OmniTech Retails',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 30).toISOString()
      },
      {
        id: 'list-logi-bigbasket',
        vendor: 'bigbasket',
        price: 9499,
        originalPrice: 10995,
        discountPercent: 14,
        productUrl: 'https://www.bigbasket.com/pd/electronics/logitech-mx-master-3s-graphite',
        inStock: false,
        rating: 4.5,
        ratingsCount: 34,
        deliveryDays: 'Currently Unavailable',
        deliveryFee: 0,
        seller: 'BB Electronic Depot',
        scrapedAt: new Date(Date.now() - 1000 * 60 * 45).toISOString()
      }
    ],
    priceHistory: [
      { date: 'Oct 01', amazon: 8995, flipkart: 9599, bigbasket: 9999 },
      { date: 'Oct 07', amazon: 8795, flipkart: 9499, bigbasket: 9899 },
      { date: 'Oct 14', amazon: 8695, flipkart: 9399, bigbasket: 9799 },
      { date: 'Oct 21', amazon: 8595, flipkart: 9349, bigbasket: 9699 },
      { date: 'Oct 25', amazon: 8495, flipkart: 9299, bigbasket: 9499 },
      { date: 'Oct 28', amazon: 8495, flipkart: 9299, bigbasket: 9499 }
    ]
  }
];

export const INITIAL_SCRAPING_JOBS: ScrapingJob[] = [
  {
    id: 'job-amz-01',
    vendor: 'amazon',
    vendorName: 'Amazon India',
    targetCategory: 'Electronics & Mobiles',
    status: 'completed',
    itemsScraped: 1420,
    retryCount: 0,
    maxRetries: 3,
    startedAt: new Date(Date.now() - 1000 * 60 * 42).toISOString(),
    durationSec: 184
  },
  {
    id: 'job-fk-02',
    vendor: 'flipkart',
    vendorName: 'Flipkart',
    targetCategory: 'Audio & Wearables',
    status: 'running',
    itemsScraped: 865,
    retryCount: 1,
    maxRetries: 3,
    startedAt: new Date(Date.now() - 1000 * 60 * 6).toISOString(),
    durationSec: 360
  },
  {
    id: 'job-bb-03',
    vendor: 'bigbasket',
    vendorName: 'BigBasket',
    targetCategory: 'Groceries & Household Staples',
    status: 'completed',
    itemsScraped: 3180,
    retryCount: 0,
    maxRetries: 3,
    startedAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    durationSec: 412
  },
  {
    id: 'job-amz-04',
    vendor: 'amazon',
    vendorName: 'Amazon India',
    targetCategory: 'Home Appliances',
    status: 'failed',
    itemsScraped: 45,
    retryCount: 3,
    maxRetries: 3,
    startedAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
    durationSec: 78,
    lastError: 'HTTP 429 Too Many Requests: Rate limit exceeded on search endpoint. Backoff applied.'
  },
  {
    id: 'job-bb-05',
    vendor: 'bigbasket',
    vendorName: 'BigBasket',
    targetCategory: 'Personal Care & Dairy',
    status: 'scheduled',
    itemsScraped: 0,
    retryCount: 0,
    maxRetries: 3,
    startedAt: new Date(Date.now() + 1000 * 60 * 60).toISOString(),
    durationSec: 0
  }
];

export const INITIAL_SCRAPING_LOGS: ScrapingLog[] = [
  {
    id: 'log-01',
    jobId: 'job-amz-01',
    vendor: 'amazon',
    timestamp: new Date(Date.now() - 1000 * 60 * 40).toISOString(),
    level: 'INFO',
    message: 'Initiated headless browser cluster with 4 concurrent worker nodes.'
  },
  {
    id: 'log-02',
    jobId: 'job-amz-01',
    vendor: 'amazon',
    timestamp: new Date(Date.now() - 1000 * 60 * 39).toISOString(),
    level: 'SUCCESS',
    message: 'Loaded 50 category catalogue pages. Selector .s-result-item matched 1,420 products.',
    selectorTested: 'div.s-result-item[data-component-type="s-search-result"]'
  },
  {
    id: 'log-03',
    jobId: 'job-fk-02',
    vendor: 'flipkart',
    timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
    level: 'WARN',
    message: 'Captcha challenge suspected on page 8. Rotating residential proxy IP address.',
    endpoint: 'https://www.flipkart.com/search?q=earbuds'
  },
  {
    id: 'log-04',
    jobId: 'job-fk-02',
    vendor: 'flipkart',
    timestamp: new Date(Date.now() - 1000 * 60 * 3).toISOString(),
    level: 'INFO',
    message: 'Proxy rotated successfully. Resuming batch extraction for 865 product listings.'
  },
  {
    id: 'log-05',
    jobId: 'job-amz-04',
    vendor: 'amazon',
    timestamp: new Date(Date.now() - 1000 * 60 * 179).toISOString(),
    level: 'ERROR',
    message: 'HTTP 429 Too Many Requests: Rate limit exceeded on search endpoint. Automatic retry count reached (3/3).',
    selectorTested: '.a-price-whole'
  },
  {
    id: 'log-06',
    jobId: 'job-bb-03',
    vendor: 'bigbasket',
    timestamp: new Date(Date.now() - 1000 * 60 * 115).toISOString(),
    level: 'SUCCESS',
    message: 'BigBasket GraphQL API catalog sync completed. 3,180 SKUs ingested into product repository.',
    endpoint: 'https://www.bigbasket.com/listing-svc/v2/products'
  }
];

export const INITIAL_SITE_CONFIGS: SiteSelectorConfig[] = [
  {
    vendor: 'amazon',
    vendorName: 'Amazon India',
    baseUrl: 'https://www.amazon.in',
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    requestDelayMs: 1200,
    selectors: {
      container: 'div[data-component-type="s-search-result"]',
      title: 'h2 a.a-link-normal span',
      price: 'span.a-price span.a-offscreen',
      originalPrice: 'span.a-price.a-text-price span.a-offscreen',
      rating: 'span.a-icon-alt',
      inStock: 'span.a-declarative[data-action="add-to-cart"]',
      imageUrl: 'img.s-image',
      productUrl: 'h2 a.a-link-normal'
    },
    lastUpdated: '2026-10-24 14:32:00',
    updatedBy: 'admin@dealpulse.com'
  },
  {
    vendor: 'flipkart',
    vendorName: 'Flipkart',
    baseUrl: 'https://www.flipkart.com',
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
    requestDelayMs: 1500,
    selectors: {
      container: 'div._1AtVbE, div.cPHDOP',
      title: 'div.KzDlHZ, a.wByoh7',
      price: 'div.Nx9bqj',
      originalPrice: 'div.yRaY8j',
      rating: 'div.XQDdHH',
      inStock: 'button._2KpZ6l._2U9uOA._3v1-ww',
      imageUrl: 'img.DByuf4',
      productUrl: 'a.CGtC58, a._1fQZEK'
    },
    lastUpdated: '2026-10-26 10:15:00',
    updatedBy: 'admin@dealpulse.com'
  },
  {
    vendor: 'bigbasket',
    vendorName: 'BigBasket',
    baseUrl: 'https://www.bigbasket.com',
    userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
    requestDelayMs: 1000,
    selectors: {
      container: 'li.PaginateItems___StyledLi',
      title: 'h3.break-words',
      price: 'span.Pricing___StyledLabel-sc-1rm012w-0',
      originalPrice: 'span.Pricing___StyledLabel2-sc-1rm012w-1',
      rating: 'span.Badges___StyledLabel-sc-157vs97-0',
      inStock: 'button.AddToCart___StyledButton',
      imageUrl: 'img.Image___StyledImg',
      productUrl: 'a.Deck___StyledA'
    },
    lastUpdated: '2026-10-27 18:40:00',
    updatedBy: 'admin@dealpulse.com'
  }
];

export const DEMO_USERS: User[] = [
  {
    id: 'usr-standard-01',
    email: 'user@example.com',
    name: 'Priya Sharma',
    role: 'user',
    createdAt: '2026-08-15T10:00:00.000Z'
  },
  {
    id: 'usr-admin-01',
    email: 'admin@dealpulse.com',
    name: 'Admin Supervisor',
    role: 'admin',
    createdAt: '2026-01-01T00:00:00.000Z'
  }
];
