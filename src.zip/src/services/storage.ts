import {
  LockoutState,
  PriceAlert,
  Product,
  ScrapingJob,
  ScrapingLog,
  SearchHistoryItem,
  SiteSelectorConfig,
  User
} from '../types';
import {
  DEMO_USERS,
  INITIAL_PRODUCTS,
  INITIAL_SCRAPING_JOBS,
  INITIAL_SCRAPING_LOGS,
  INITIAL_SITE_CONFIGS
} from './mockData';

const KEYS = {
  CURRENT_USER: 'cpf_current_user',
  SEARCH_HISTORY: 'cpf_search_history',
  PRICE_ALERTS: 'cpf_price_alerts',
  PRODUCTS: 'cpf_products',
  SCRAPING_JOBS: 'cpf_scraping_jobs',
  SCRAPING_LOGS: 'cpf_scraping_logs',
  SITE_CONFIGS: 'cpf_site_configs',
  LOCKOUT_STATE: 'cpf_lockout_state',
  USERS: 'cpf_registered_users'
};

// Default initial lockout state
const DEFAULT_LOCKOUT: LockoutState = {
  failedAttempts: 0,
  isLocked: false,
  lockedUntil: null
};

export const Storage = {
  // Current User
  getUser(): User | null {
    const raw = localStorage.getItem(KEYS.CURRENT_USER);
    if (!raw) return DEMO_USERS[0]; // Default logged-in demo user for immediate convenience
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  },

  setUser(user: User | null) {
    if (!user) {
      localStorage.removeItem(KEYS.CURRENT_USER);
    } else {
      localStorage.setItem(KEYS.CURRENT_USER, JSON.stringify(user));
    }
  },

  // Registered Users (for local auth verification)
  getRegisteredUsers(): User[] {
    const raw = localStorage.getItem(KEYS.USERS);
    if (!raw) {
      localStorage.setItem(KEYS.USERS, JSON.stringify(DEMO_USERS));
      return DEMO_USERS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return DEMO_USERS;
    }
  },

  addRegisteredUser(user: User) {
    const users = this.getRegisteredUsers();
    users.push(user);
    localStorage.setItem(KEYS.USERS, JSON.stringify(users));
  },

  // Lockout State (5 failed attempts lockout)
  getLockoutState(): LockoutState {
    const raw = localStorage.getItem(KEYS.LOCKOUT_STATE);
    if (!raw) return { ...DEFAULT_LOCKOUT };
    try {
      const parsed: LockoutState = JSON.parse(raw);
      // Check if locked timer has expired
      if (parsed.isLocked && parsed.lockedUntil && Date.now() >= parsed.lockedUntil) {
        const reset: LockoutState = {
          failedAttempts: 0,
          isLocked: false,
          lockedUntil: null
        };
        this.setLockoutState(reset);
        return reset;
      }
      return parsed;
    } catch {
      return { ...DEFAULT_LOCKOUT };
    }
  },

  setLockoutState(state: LockoutState) {
    localStorage.setItem(KEYS.LOCKOUT_STATE, JSON.stringify(state));
  },

  recordFailedLoginAttempt(): LockoutState {
    const current = this.getLockoutState();
    const newCount = current.failedAttempts + 1;

    if (newCount >= 5) {
      // Lock for 60 seconds (1 minute lockout)
      const lockedState: LockoutState = {
        failedAttempts: newCount,
        isLocked: true,
        lockedUntil: Date.now() + 60 * 1000
      };
      this.setLockoutState(lockedState);
      return lockedState;
    }

    const updatedState: LockoutState = {
      failedAttempts: newCount,
      isLocked: false,
      lockedUntil: null
    };
    this.setLockoutState(updatedState);
    return updatedState;
  },

  resetLockout() {
    this.setLockoutState({ ...DEFAULT_LOCKOUT });
  },

  // Products
  getProducts(): Product[] {
    const raw = localStorage.getItem(KEYS.PRODUCTS);
    if (!raw) {
      localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(INITIAL_PRODUCTS));
      return INITIAL_PRODUCTS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_PRODUCTS;
    }
  },

  // Search History
  getSearchHistory(): SearchHistoryItem[] {
    const raw = localStorage.getItem(KEYS.SEARCH_HISTORY);
    if (!raw) {
      // Seed with initial realistic search history for instant presentation
      const initialHistory: SearchHistoryItem[] = [
        {
          id: 'hist-01',
          query: 'iPhone 15',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
          resultCount: 1,
          cheapestPriceFound: 65999,
          bestVendor: 'flipkart'
        },
        {
          id: 'hist-02',
          query: 'Aashirvaad Atta 5kg',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
          resultCount: 1,
          cheapestPriceFound: 319,
          bestVendor: 'bigbasket'
        },
        {
          id: 'hist-03',
          query: 'Sony WH-1000XM5',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(),
          resultCount: 1,
          cheapestPriceFound: 26990,
          bestVendor: 'amazon'
        }
      ];
      localStorage.setItem(KEYS.SEARCH_HISTORY, JSON.stringify(initialHistory));
      return initialHistory;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  addSearchHistoryItem(item: Omit<SearchHistoryItem, 'id' | 'timestamp'>): SearchHistoryItem {
    const history = this.getSearchHistory();
    const newItem: SearchHistoryItem = {
      ...item,
      id: 'hist-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toISOString()
    };
    // Keep most recent first, max 50 items
    const updated = [newItem, ...history.filter(h => h.query.toLowerCase() !== item.query.toLowerCase())].slice(0, 50);
    localStorage.setItem(KEYS.SEARCH_HISTORY, JSON.stringify(updated));
    return newItem;
  },

  removeSearchHistoryItem(id: string) {
    const history = this.getSearchHistory().filter(h => h.id !== id);
    localStorage.setItem(KEYS.SEARCH_HISTORY, JSON.stringify(history));
  },

  clearSearchHistory() {
    localStorage.setItem(KEYS.SEARCH_HISTORY, JSON.stringify([]));
  },

  // Price Alerts
  getPriceAlerts(): PriceAlert[] {
    const raw = localStorage.getItem(KEYS.PRICE_ALERTS);
    if (!raw) {
      const initialAlerts: PriceAlert[] = [
        {
          id: 'alert-01',
          productId: 'prod-iphone-15',
          productTitle: 'Apple iPhone 15 (128 GB) - Black',
          productImage: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=600&auto=format&fit=crop&q=80',
          targetPrice: 62000,
          currentLowestPrice: 65999,
          cheapestVendor: 'flipkart',
          notifyEmail: true,
          emailAddress: 'user@example.com',
          notifyPush: true,
          createdAt: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
          status: 'active',
          lastChecked: new Date(Date.now() - 1000 * 60 * 30).toISOString()
        },
        {
          id: 'alert-02',
          productId: 'prod-boat-airdopes',
          productTitle: 'Boat Airdopes 141 ANC True Wireless Earbuds',
          productImage: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=600&auto=format&fit=crop&q=80',
          targetPrice: 1200,
          currentLowestPrice: 1199,
          cheapestVendor: 'flipkart',
          notifyEmail: true,
          emailAddress: 'user@example.com',
          notifyPush: false,
          createdAt: new Date(Date.now() - 1000 * 60 * 60 * 120).toISOString(),
          status: 'triggered',
          lastChecked: new Date(Date.now() - 1000 * 60 * 10).toISOString()
        }
      ];
      localStorage.setItem(KEYS.PRICE_ALERTS, JSON.stringify(initialAlerts));
      return initialAlerts;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  addPriceAlert(alert: Omit<PriceAlert, 'id' | 'createdAt' | 'status' | 'lastChecked'>): PriceAlert {
    const alerts = this.getPriceAlerts();
    const newAlert: PriceAlert = {
      ...alert,
      id: 'alert-' + Date.now(),
      createdAt: new Date().toISOString(),
      status: alert.currentLowestPrice <= alert.targetPrice ? 'triggered' : 'active',
      lastChecked: new Date().toISOString()
    };
    alerts.unshift(newAlert);
    localStorage.setItem(KEYS.PRICE_ALERTS, JSON.stringify(alerts));
    return newAlert;
  },

  removePriceAlert(id: string) {
    const alerts = this.getPriceAlerts().filter(a => a.id !== id);
    localStorage.setItem(KEYS.PRICE_ALERTS, JSON.stringify(alerts));
  },

  togglePriceAlertStatus(id: string) {
    const alerts = this.getPriceAlerts().map(a => {
      if (a.id === id) {
        return {
          ...a,
          status: a.status === 'paused' ? ('active' as const) : ('paused' as const)
        };
      }
      return a;
    });
    localStorage.setItem(KEYS.PRICE_ALERTS, JSON.stringify(alerts));
  },

  // Admin Scraping Jobs
  getScrapingJobs(): ScrapingJob[] {
    const raw = localStorage.getItem(KEYS.SCRAPING_JOBS);
    if (!raw) {
      localStorage.setItem(KEYS.SCRAPING_JOBS, JSON.stringify(INITIAL_SCRAPING_JOBS));
      return INITIAL_SCRAPING_JOBS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_SCRAPING_JOBS;
    }
  },

  updateScrapingJob(updatedJob: ScrapingJob) {
    const jobs = this.getScrapingJobs().map(j => j.id === updatedJob.id ? updatedJob : j);
    localStorage.setItem(KEYS.SCRAPING_JOBS, JSON.stringify(jobs));
  },

  // Scraping Logs
  getScrapingLogs(): ScrapingLog[] {
    const raw = localStorage.getItem(KEYS.SCRAPING_LOGS);
    if (!raw) {
      localStorage.setItem(KEYS.SCRAPING_LOGS, JSON.stringify(INITIAL_SCRAPING_LOGS));
      return INITIAL_SCRAPING_LOGS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_SCRAPING_LOGS;
    }
  },

  addScrapingLog(log: Omit<ScrapingLog, 'id' | 'timestamp'>) {
    const logs = this.getScrapingLogs();
    const newLog: ScrapingLog = {
      ...log,
      id: 'log-' + Date.now(),
      timestamp: new Date().toISOString()
    };
    logs.unshift(newLog);
    localStorage.setItem(KEYS.SCRAPING_LOGS, JSON.stringify(logs.slice(0, 100)));
  },

  clearScrapingLogs() {
    localStorage.setItem(KEYS.SCRAPING_LOGS, JSON.stringify([]));
  },

  // Site Selector Configs
  getSiteConfigs(): SiteSelectorConfig[] {
    const raw = localStorage.getItem(KEYS.SITE_CONFIGS);
    if (!raw) {
      localStorage.setItem(KEYS.SITE_CONFIGS, JSON.stringify(INITIAL_SITE_CONFIGS));
      return INITIAL_SITE_CONFIGS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_SITE_CONFIGS;
    }
  },

  updateSiteConfig(updatedConfig: SiteSelectorConfig) {
    const configs = this.getSiteConfigs().map(c => c.vendor === updatedConfig.vendor ? updatedConfig : c);
    localStorage.setItem(KEYS.SITE_CONFIGS, JSON.stringify(configs));
  }
};
