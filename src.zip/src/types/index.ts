export type VendorId = 'amazon' | 'flipkart' | 'bigbasket';

export interface VendorInfo {
  id: VendorId;
  name: string;
  tagline: string;
  brandColor: string;
  badgeBg: string;
  logoText: string;
  logoBg: string;
  domain: string;
}

export interface PriceListing {
  id: string;
  vendor: VendorId;
  price: number;
  originalPrice: number;
  discountPercent: number;
  productUrl: string;
  inStock: boolean;
  rating: number;
  ratingsCount: number;
  deliveryDays: string;
  deliveryFee: number;
  seller: string;
  scrapedAt: string;
}

export interface PriceHistoryPoint {
  date: string;
  amazon?: number;
  flipkart?: number;
  bigbasket?: number;
}

export interface Product {
  id: string;
  title: string;
  category: string;
  brand: string;
  imageUrl: string;
  description: string;
  specs: Record<string, string>;
  listings: PriceListing[];
  priceHistory: PriceHistoryPoint[];
  cheapestVendor: VendorId;
  cheapestPrice: number;
  highestPrice: number;
  savingsAmount: number;
  savingsPercent: number;
  averageRating: number;
}

export interface SearchFilters {
  query: string;
  category: string;
  brands: string[];
  minPrice: number;
  maxPrice: number;
  minRating: number;
  vendors: VendorId[];
  inStockOnly: boolean;
  sortBy: 'price_asc' | 'price_desc' | 'rating_desc' | 'discount_desc' | 'savings_desc';
}

export interface SearchHistoryItem {
  id: string;
  query: string;
  timestamp: string; // ISO string
  resultCount: number;
  cheapestPriceFound?: number;
  bestVendor?: VendorId;
  savedFilters?: Partial<SearchFilters>;
}

export interface PriceAlert {
  id: string;
  productId: string;
  productTitle: string;
  productImage: string;
  targetPrice: number;
  currentLowestPrice: number;
  cheapestVendor: VendorId;
  notifyEmail: boolean;
  emailAddress: string;
  notifyPush: boolean;
  createdAt: string;
  status: 'active' | 'triggered' | 'paused';
  lastChecked: string;
}

export interface ScrapingJob {
  id: string;
  vendor: VendorId;
  vendorName: string;
  targetCategory: string;
  status: 'running' | 'completed' | 'failed' | 'scheduled';
  itemsScraped: number;
  retryCount: number;
  maxRetries: number;
  startedAt: string;
  durationSec: number;
  lastError?: string;
}

export interface ScrapingLog {
  id: string;
  jobId: string;
  vendor: VendorId;
  timestamp: string;
  level: 'INFO' | 'WARN' | 'ERROR' | 'SUCCESS';
  message: string;
  selectorTested?: string;
  endpoint?: string;
}

export interface SiteSelectorConfig {
  vendor: VendorId;
  vendorName: string;
  baseUrl: string;
  userAgent: string;
  requestDelayMs: number;
  selectors: {
    container: string;
    title: string;
    price: string;
    originalPrice: string;
    rating: string;
    inStock: string;
    imageUrl: string;
    productUrl: string;
  };
  lastUpdated: string;
  updatedBy: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  createdAt: string;
}

export interface LockoutState {
  failedAttempts: number;
  isLocked: boolean;
  lockedUntil: number | null; // epoch timestamp ms
}
