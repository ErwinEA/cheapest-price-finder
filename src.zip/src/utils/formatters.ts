import { VendorId, VendorInfo } from '../types';

export const VENDORS: Record<VendorId, VendorInfo> = {
  amazon: {
    id: 'amazon',
    name: 'Amazon India',
    tagline: 'Fast delivery & Prime deals',
    brandColor: '#ff9900',
    badgeBg: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    logoText: 'Amazon',
    logoBg: 'bg-slate-900 border-amber-500/30 text-amber-400',
    domain: 'amazon.in'
  },
  flipkart: {
    id: 'flipkart',
    name: 'Flipkart',
    tagline: 'SuperCoins & Plus benefits',
    brandColor: '#2874f0',
    badgeBg: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    logoText: 'Flipkart',
    logoBg: 'bg-slate-900 border-blue-500/30 text-blue-400',
    domain: 'flipkart.com'
  },
  bigbasket: {
    id: 'bigbasket',
    name: 'BigBasket',
    tagline: 'Groceries, fresh & FMCG staples',
    brandColor: '#84c225',
    badgeBg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    logoText: 'BigBasket',
    logoBg: 'bg-slate-900 border-emerald-500/30 text-emerald-400',
    domain: 'bigbasket.com'
  }
};

/**
 * Format number as Indian Rupee (₹)
 */
export function formatCurrency(amount: number): string {
  if (amount === undefined || amount === null || isNaN(amount)) return '₹0';
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(amount);
}

/**
 * Format full exact date and timestamp
 */
export function formatExactDateTime(isoString: string): string {
  try {
    const d = new Date(isoString);
    return new Intl.DateTimeFormat('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(d);
  } catch {
    return isoString;
  }
}

/**
 * Human-friendly relative time
 */
export function formatRelativeTime(isoString: string): string {
  try {
    const d = new Date(isoString).getTime();
    const now = Date.now();
    const diffSec = Math.floor((now - d) / 1000);

    if (diffSec < 60) return 'Just now';
    if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
    if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
    return `${Math.floor(diffSec / 86400)}d ago`;
  } catch {
    return 'Recently';
  }
}
