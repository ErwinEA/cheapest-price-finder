/**
 * Security and sanitization utilities for user inputs.
 * Specifically satisfies the constraint:
 * "Input fields, especially the primary search box, must sanitize inputs to prevent SQL injection and gracefully handle errors without exposing database text."
 */

// Common SQL Injection patterns and signatures
const SQL_INJECTION_PATTERNS = [
  /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|EXEC|EXECUTE|UNION|GRANT|REVOKE)\b)/gi,
  /(--|#|\/\*|\*\/)/g,                       // SQL comments
  /('|"|;)\s*(OR|AND)\s*('|"|1|true)/gi,     // Boolean-based injections like ' OR 1=1
  /('|"|;)\s*=\s*('|"|1)/gi,
  /\bWAITFOR\s+DELAY\b/gi,                   // Time-based blind SQLi
  /\bSLEEP\s*\(/gi,
  /\bBENCHMARK\s*\(/gi,
  /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, // Basic XSS script tags
  /javascript:/gi
];

export interface SanitizationResult {
  isValid: boolean;
  sanitized: string;
  original: string;
  hasSecurityRisk: boolean;
  threatDetails?: string;
  errorMessage?: string;
}

/**
 * Validates and sanitizes search queries.
 * - Explicitly rejects empty or whitespace-only inputs.
 * - Strips dangerous SQL keywords, comments, and delimiters.
 * - Gracefully flags security risks while returning a safe sanitized string.
 */
export function sanitizeSearchQuery(input: string): SanitizationResult {
  if (!input || typeof input !== 'string') {
    return {
      isValid: false,
      sanitized: '',
      original: '',
      hasSecurityRisk: false,
      errorMessage: 'Search query cannot be empty. Please enter a product name.'
    };
  }

  const trimmed = input.trim();

  if (trimmed.length === 0) {
    return {
      isValid: false,
      sanitized: '',
      original: input,
      hasSecurityRisk: false,
      errorMessage: 'Search query cannot be empty. Please enter a product name.'
    };
  }

  // Check for potential SQL injection vectors
  let hasSecurityRisk = false;
  let threatDetails = '';

  for (const pattern of SQL_INJECTION_PATTERNS) {
    if (pattern.test(trimmed)) {
      hasSecurityRisk = true;
      threatDetails = 'Suspicious SQL or script meta-characters detected and sanitized.';
      break;
    }
  }

  // Strip dangerous SQL meta-characters: quotes, semicolons, comments, backticks
  let sanitized = trimmed
    .replace(/['";\\]/g, '')             // remove quotes and semicolons
    .replace(/--.*$/g, '')               // remove single-line comments
    .replace(/\/\*[\s\S]*?\*\//g, '')    // remove multi-line comments
    .replace(/[<>]/g, '')                // remove HTML brackets to prevent XSS
    .replace(/\s+/g, ' ')                // normalize multiple spaces
    .trim();

  // If after sanitization nothing remains
  if (sanitized.length === 0) {
    return {
      isValid: false,
      sanitized: '',
      original: input,
      hasSecurityRisk: true,
      threatDetails: 'Input contained only restricted characters.',
      errorMessage: 'Invalid characters in search query. Please use standard alphanumeric search terms.'
    };
  }

  return {
    isValid: true,
    sanitized,
    original: input,
    hasSecurityRisk,
    threatDetails: hasSecurityRisk ? threatDetails : undefined
  };
}

/**
 * Gracefully formats any error without exposing raw database, SQL, or internal stack details.
 */
export function formatSafeErrorMessage(error: unknown): string {
  if (!error) return 'An unexpected error occurred. Please try again.';

  let rawMessage = '';
  if (error instanceof Error) {
    rawMessage = error.message;
  } else if (typeof error === 'string') {
    rawMessage = error;
  } else {
    rawMessage = JSON.stringify(error);
  }

  // Check if error contains database syntax, Postgres, MySQL, SQLite, or stack traces
  const dbSignatures = [
    /syntax error at or near/i,
    /pg_query/i,
    /ORA-\d+/i,
    /MySQL server version/i,
    /SQLSTATE/i,
    /sqlite3/i,
    /relation ".*" does not exist/i,
    /column ".*" does not exist/i,
    /table ".*" doesn't exist/i,
    /UnhandledPromiseRejection/i,
    /at \w+ \(/i
  ];

  const containsDbLeak = dbSignatures.some(sig => sig.test(rawMessage));

  if (containsDbLeak) {
    // Shield internal details from the user
    return 'Search service is currently unable to process this request. Please try a different query.';
  }

  return rawMessage;
}
