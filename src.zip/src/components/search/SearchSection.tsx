import React, { useState, useEffect } from 'react';
import { SearchFilters, VendorId } from '../../types';
import { sanitizeSearchQuery } from '../../utils/security';
import {
  Search,
  SlidersHorizontal,
  X,
  ShieldCheck,
  ShieldAlert,
  ArrowUpDown,
  Sparkles,
  RotateCcw,
  Zap
} from 'lucide-react';

interface SearchSectionProps {
  filters: SearchFilters;
  onSearch: (filters: SearchFilters) => void;
  isLoading: boolean;
  sanitizationNotice?: string;
  totalResultsCount?: number;
}

const POPULAR_SUGGESTIONS = [
  'iPhone 15',
  'Aashirvaad Atta 5kg',
  'Sony WH-1000XM5',
  'Sunflower Oil 5L',
  'Samsung S24 Ultra',
  'Boat Airdopes 141',
  'Surf Excel Matic',
  'Tata Tea Gold'
];

const AVAILABLE_BRANDS = [
  'Apple',
  'Samsung',
  'Sony',
  'Aashirvaad',
  'Fortune',
  'Tata Tea',
  'Boat',
  'Surf Excel',
  'Logitech'
];

export const SearchSection: React.FC<SearchSectionProps> = ({
  filters,
  onSearch,
  isLoading,
  sanitizationNotice,
  totalResultsCount
}) => {
  const [searchInput, setSearchInput] = useState(filters.query);
  const [showFilters, setShowFilters] = useState(false);
  const [localFilters, setLocalFilters] = useState<SearchFilters>(filters);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [securityWarning, setSecurityWarning] = useState<string | null>(null);

  // Sync external filters changes
  useEffect(() => {
    setSearchInput(filters.query);
    setLocalFilters(filters);
  }, [filters]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setValidationError(null);
    setSecurityWarning(null);

    // Frontend query validation: explicitly reject empty inputs
    const check = sanitizeSearchQuery(searchInput);
    if (!check.isValid) {
      setValidationError(check.errorMessage || 'Please enter a product name to search.');
      return;
    }

    if (check.hasSecurityRisk) {
      setSecurityWarning(check.threatDetails || 'Input sanitized for safety.');
    }

    const updated = {
      ...localFilters,
      query: check.sanitized
    };
    setLocalFilters(updated);
    onSearch(updated);
  };

  const handleQuickSuggestion = (item: string) => {
    setSearchInput(item);
    setValidationError(null);
    setSecurityWarning(null);
    const updated = {
      ...localFilters,
      query: item
    };
    setLocalFilters(updated);
    onSearch(updated);
  };

  const handleVendorToggle = (vendor: VendorId) => {
    const current = localFilters.vendors || [];
    const next = current.includes(vendor)
      ? current.filter(v => v !== vendor)
      : [...current, vendor];
    const updated = { ...localFilters, vendors: next };
    setLocalFilters(updated);
    onSearch(updated);
  };

  const handleBrandToggle = (brand: string) => {
    const current = localFilters.brands || [];
    const next = current.includes(brand)
      ? current.filter(b => b !== brand)
      : [...current, brand];
    const updated = { ...localFilters, brands: next };
    setLocalFilters(updated);
    onSearch(updated);
  };

  const handleResetFilters = () => {
    const reset: SearchFilters = {
      query: searchInput,
      category: 'All',
      brands: [],
      minPrice: 0,
      maxPrice: 150000,
      minRating: 0,
      vendors: ['amazon', 'flipkart', 'bigbasket'],
      inStockOnly: false,
      sortBy: 'price_asc'
    };
    setLocalFilters(reset);
    onSearch(reset);
  };

  return (
    <div className="w-full">
      {/* Search Input Container - Trading Terminal Theme */}
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative flex items-center">
          <div className="absolute left-4 pointer-events-none text-slate-400">
            <Search className="w-5 h-5 text-slate-400" />
          </div>

          <input
            type="text"
            value={searchInput}
            onChange={(e) => {
              setSearchInput(e.target.value);
              if (validationError) setValidationError(null);
            }}
            placeholder="Search & match prices across Amazon, Flipkart, & BigBasket (e.g. iPhone 15, Atta, Sony XM5)..."
            className={`w-full pl-12 pr-36 py-4 rounded-2xl bg-[#0D1017] text-white placeholder-slate-500 border text-base shadow-2xl focus:outline-none transition-all duration-200 ${
              validationError
                ? 'border-[#FF3B30] ring-2 ring-[#FF3B30]/20'
                : 'border-white/[0.1] focus:border-[#C8F902] focus:ring-4 focus:ring-[#C8F902]/15'
            }`}
          />

          <div className="absolute right-2.5 flex items-center gap-2">
            {searchInput && (
              <button
                type="button"
                onClick={() => {
                  setSearchInput('');
                  setValidationError(null);
                }}
                className="text-slate-400 hover:text-white p-1.5 transition-colors"
                title="Clear input"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            <button
              type="button"
              onClick={() => setShowFilters(!showFilters)}
              className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all ${
                showFilters
                  ? 'bg-[#C8F902] text-[#08090C] border-[#C8F902] font-bold shadow-glow-lime'
                  : 'bg-[#141824] hover:bg-[#1a2030] text-slate-300 border-white/[0.08]'
              }`}
              title="Toggle filters"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Filters</span>
            </button>

            <button
              type="submit"
              disabled={isLoading}
              className="px-5 py-2.5 rounded-xl btn-lime text-xs uppercase tracking-wider disabled:opacity-50 flex items-center gap-1.5"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>{isLoading ? 'Scanning...' : 'Scan Best Bid'}</span>
            </button>
          </div>
        </div>

        {/* Query Validation Error Notice */}
        {validationError && (
          <div className="mt-2 text-xs text-[#FF3B30] flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#FF3B30]/10 border border-[#FF3B30]/30 animate-fadeIn font-mono">
            <X className="w-4 h-4 text-[#FF3B30] flex-shrink-0" />
            <span>{validationError}</span>
          </div>
        )}

        {/* Security & Sanitization Alerts */}
        {(securityWarning || sanitizationNotice) && (
          <div className="mt-2 text-xs text-amber-300 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-950/40 border border-amber-500/30 animate-fadeIn font-mono">
            <ShieldAlert className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <span>
              <strong>Security Sanitizer Active:</strong>{' '}
              {securityWarning || sanitizationNotice}
            </span>
          </div>
        )}
      </form>

      {/* 3-Step Flow Banner & Fast Suggestions */}
      <div className="mt-3.5 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-slate-400 font-medium flex items-center gap-1 text-[11px] uppercase tracking-wider font-mono">
            <Sparkles className="w-3 h-3 text-[#C8F902]" />
            Trending Deals:
          </span>
          {POPULAR_SUGGESTIONS.map((item) => (
            <button
              key={item}
              onClick={() => handleQuickSuggestion(item)}
              className="px-2.5 py-1 rounded-lg bg-[#0D1017] hover:bg-[#161B26] border border-white/[0.08] hover:border-[#C8F902]/40 text-slate-300 hover:text-white transition-all text-[11px]"
            >
              {item}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 text-[10px] text-slate-400 bg-[#0D1017] px-2.5 py-1 rounded-lg border border-white/[0.08] font-mono">
          <ShieldCheck className="w-3.5 h-3.5 text-[#C8F902]" />
          <span>SQL-Sanitized • 3-Node Aggregator</span>
        </div>
      </div>

      {/* Expanded Filter Panel - Bento Grid Trading Style */}
      {showFilters && (
        <div className="mt-4 p-5 sm:p-6 rounded-2xl trading-card animate-fadeIn">
          <div className="flex items-center justify-between pb-3.5 border-b border-white/[0.08]">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-[#C8F902]" />
              <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                Market Filter Parameters
              </h4>
            </div>
            <button
              onClick={handleResetFilters}
              className="text-xs text-slate-400 hover:text-[#C8F902] flex items-center gap-1 transition-colors font-mono"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Filters</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-5">
            {/* Vendor Selector */}
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-2 uppercase tracking-wider font-mono">
                Target Vendors
              </label>
              <div className="space-y-2">
                {[
                  { id: 'amazon' as VendorId, name: 'Amazon India', color: 'border-amber-500/40 text-amber-400 bg-amber-500/10' },
                  { id: 'flipkart' as VendorId, name: 'Flipkart', color: 'border-blue-500/40 text-blue-400 bg-blue-500/10' },
                  { id: 'bigbasket' as VendorId, name: 'BigBasket', color: 'border-emerald-500/40 text-emerald-400 bg-emerald-500/10' },
                ].map(v => {
                  const isChecked = localFilters.vendors.includes(v.id);
                  return (
                    <label
                      key={v.id}
                      className={`flex items-center justify-between p-2.5 rounded-xl border text-xs cursor-pointer transition-colors ${
                        isChecked ? v.color : 'bg-[#06080C] border-white/[0.06] text-slate-400'
                      }`}
                    >
                      <span className="font-semibold">{v.name}</span>
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => handleVendorToggle(v.id)}
                        className="rounded border-slate-700 text-[#C8F902] focus:ring-0"
                      />
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Price Range Slider */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider font-mono">
                  Max Price Ceiling
                </label>
                <span className="text-xs font-mono font-black text-[#C8F902]">
                  ₹{localFilters.maxPrice.toLocaleString('en-IN')}
                </span>
              </div>
              <input
                type="range"
                min="100"
                max="150000"
                step="250"
                value={localFilters.maxPrice}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  const updated = { ...localFilters, maxPrice: val };
                  setLocalFilters(updated);
                  onSearch(updated);
                }}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#C8F902]"
              />
              <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1.5">
                <span>₹100</span>
                <span>₹1,50,000</span>
              </div>

              {/* In-Stock Toggle */}
              <div className="mt-4 pt-3 border-t border-white/[0.06]">
                <label className="flex items-center justify-between text-xs cursor-pointer text-slate-300">
                  <span className="font-medium">In-Stock Listings Only</span>
                  <input
                    type="checkbox"
                    checked={localFilters.inStockOnly}
                    onChange={(e) => {
                      const updated = { ...localFilters, inStockOnly: e.target.checked };
                      setLocalFilters(updated);
                      onSearch(updated);
                    }}
                    className="rounded border-slate-700 text-[#C8F902] focus:ring-0"
                  />
                </label>
              </div>
            </div>

            {/* Brands Filter */}
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-2 uppercase tracking-wider font-mono">
                Filter by Brand
              </label>
              <div className="max-h-36 overflow-y-auto space-y-1 pr-1">
                {AVAILABLE_BRANDS.map(brand => {
                  const isChecked = localFilters.brands.includes(brand);
                  return (
                    <label
                      key={brand}
                      className="flex items-center justify-between text-xs text-slate-300 hover:text-white p-1.5 rounded-lg hover:bg-white/[0.04] cursor-pointer"
                    >
                      <span>{brand}</span>
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => handleBrandToggle(brand)}
                        className="rounded border-slate-700 text-[#C8F902] focus:ring-0"
                      />
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Sorting & Minimum Rating */}
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-2 uppercase tracking-wider font-mono flex items-center gap-1">
                <ArrowUpDown className="w-3 h-3 text-[#C8F902]" />
                Sort Ranking Mode
              </label>
              <select
                value={localFilters.sortBy}
                onChange={(e) => {
                  const updated = { ...localFilters, sortBy: e.target.value as any };
                  setLocalFilters(updated);
                  onSearch(updated);
                }}
                className="w-full bg-[#06080C] border border-white/[0.1] rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-[#C8F902] font-mono"
              >
                <option value="price_asc">Lowest Price (Best Deal)</option>
                <option value="savings_desc">Highest Cash Savings</option>
                <option value="rating_desc">Highest Customer Rating</option>
                <option value="price_desc">Price: High to Low</option>
              </select>

              <div className="mt-4">
                <label className="text-[11px] font-bold text-slate-300 block mb-1.5 uppercase tracking-wider font-mono">
                  Minimum Score
                </label>
                <div className="flex gap-2">
                  {[0, 4.0, 4.5].map((rt) => (
                    <button
                      key={rt}
                      type="button"
                      onClick={() => {
                        const updated = { ...localFilters, minRating: rt };
                        setLocalFilters(updated);
                        onSearch(updated);
                      }}
                      className={`flex-1 py-1 rounded-lg text-xs font-mono font-medium border transition-colors ${
                        localFilters.minRating === rt
                          ? 'bg-[#C8F902]/15 text-[#C8F902] border-[#C8F902]/40 font-bold'
                          : 'bg-[#06080C] text-slate-400 border-white/[0.06] hover:border-white/[0.12]'
                      }`}
                    >
                      {rt === 0 ? 'All' : `${rt}+ ★`}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Result Count Status Bar */}
      {totalResultsCount !== undefined && (
        <div className="mt-4 flex items-center justify-between text-xs text-slate-400 px-1 font-mono">
          <span>
            Matched <strong className="text-white font-bold">{totalResultsCount}</strong> catalog listings
          </span>
          <span className="text-[#C8F902] font-bold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#C8F902]"></span>
            Ranked lowest ask price first
          </span>
        </div>
      )}
    </div>
  );
};
