import React from 'react';
import { SearchHistoryItem } from '../../types';
import { formatCurrency, formatExactDateTime, VENDORS } from '../../utils/formatters';
import {
  History,
  RotateCcw,
  Trash2,
  Calendar,
  Search,
  Award
} from 'lucide-react';

interface SearchHistoryProps {
  history: SearchHistoryItem[];
  onRepeatSearch: (query: string) => void;
  onDeleteItem: (id: string) => void;
  onClearAll: () => void;
}

export const SearchHistory: React.FC<SearchHistoryProps> = ({
  history,
  onRepeatSearch,
  onDeleteItem,
  onClearAll
}) => {
  if (history.length === 0) {
    return (
      <div className="trading-card rounded-3xl p-12 text-center max-w-2xl mx-auto shadow-2xl">
        <div className="w-14 h-14 mx-auto rounded-2xl bg-[#C8F902]/10 border border-[#C8F902]/20 flex items-center justify-center text-[#C8F902] mb-4">
          <History className="w-7 h-7" />
        </div>
        <h3 className="text-lg font-bold text-white uppercase tracking-wider font-mono">No Search History Logged</h3>
        <p className="text-xs text-slate-400 mt-1.5 max-w-md mx-auto leading-relaxed">
          Executions you run across Amazon, Flipkart, and BigBasket are timestamped and preserved in this audit log with historical lowest bid prices.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header with clear button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-[#C8F902]" />
            <h2 className="text-xl font-black text-white tracking-tight uppercase font-mono">
              Search Query Audit Log
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Exact execution timestamps, recorded lowest quotes, and instant 1-click repeat search.
          </p>
        </div>

        <button
          onClick={onClearAll}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-mono font-semibold bg-[#FF3B30]/10 hover:bg-[#FF3B30]/20 text-[#FF3B30] border border-[#FF3B30]/30 transition-colors w-fit"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Purge All History</span>
        </button>
      </div>

      {/* History Cards List */}
      <div className="space-y-3">
        {history.map((item) => {
          const vendor = item.bestVendor ? VENDORS[item.bestVendor] : null;

          return (
            <div
              key={item.id}
              className="trading-card hover:border-white/[0.15] rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl transition-all"
            >
              {/* Query & Timestamp info */}
              <div className="space-y-1.5">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-[#141824] text-[#C8F902] border border-white/[0.08]">
                    <Search className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white tracking-tight">
                      "{item.query}"
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 font-mono">
                      <span className="flex items-center gap-1 text-[11px]">
                        <Calendar className="w-3 h-3 text-slate-500" />
                        <span>{formatExactDateTime(item.timestamp)}</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Additional metadata */}
                <div className="flex items-center gap-3 text-xs pt-1 sm:pl-11 font-mono">
                  <span className="text-slate-400">
                    Matches: <strong className="text-white">{item.resultCount} SKUs</strong>
                  </span>

                  {item.cheapestPriceFound && vendor && (
                    <span className="flex items-center gap-1 text-[#C8F902] bg-[#C8F902]/10 px-2 py-0.5 rounded border border-[#C8F902]/25 text-[11px] font-bold">
                      <Award className="w-3 h-3 text-[#C8F902]" />
                      Lowest: {formatCurrency(item.cheapestPriceFound)} ({vendor.name})
                    </span>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 self-end sm:self-center">
                <button
                  onClick={() => onRepeatSearch(item.query)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-mono font-bold btn-lime"
                  title="Run this search again"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Repeat Search</span>
                </button>

                <button
                  onClick={() => onDeleteItem(item.id)}
                  className="p-2 rounded-xl text-slate-400 hover:text-[#FF3B30] hover:bg-[#FF3B30]/10 border border-transparent hover:border-[#FF3B30]/20 transition-all"
                  title="Delete from history"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
