import React from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend
} from 'recharts';
import { PriceHistoryPoint } from '../../types';
import { formatCurrency } from '../../utils/formatters';
import { TrendingDown, Activity } from 'lucide-react';

interface PriceHistoryChartProps {
  data: PriceHistoryPoint[];
  productTitle: string;
}

export const PriceHistoryChart: React.FC<PriceHistoryChartProps> = ({ data, productTitle }) => {
  if (!data || data.length === 0) {
    return (
      <div className="p-6 text-center text-slate-400 text-xs font-mono">
        No price history recorded yet for this asset.
      </div>
    );
  }

  // Calculate min and max for auto-scaling Y-axis nicely
  const allPrices = data.flatMap(d => [d.amazon, d.flipkart, d.bigbasket].filter(Boolean) as number[]);
  const minPrice = Math.min(...allPrices);
  const maxPrice = Math.max(...allPrices);
  const yDomainMin = Math.max(0, Math.floor(minPrice * 0.9));
  const yDomainMax = Math.ceil(maxPrice * 1.05);

  return (
    <div className="bg-[#080A0F] border border-white/[0.08] rounded-2xl p-5 shadow-2xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-4 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#C8F902]" />
            <h4 className="text-xs font-bold text-white tracking-wider uppercase font-mono">
              30-Day Multi-Vendor Price Movement
            </h4>
          </div>
          <p className="text-xs text-slate-400 mt-0.5 truncate max-w-md font-sans">
            {productTitle}
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs bg-[#0D1017] text-slate-300 px-3 py-1.5 rounded-xl border border-white/[0.08] font-mono">
          <TrendingDown className="w-3.5 h-3.5 text-[#C8F902]" />
          <span>All-time Low: <strong className="text-[#C8F902] font-black">{formatCurrency(minPrice)}</strong></span>
        </div>
      </div>

      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 10, right: 20, left: 10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#161B26" vertical={false} />
            <XAxis
              dataKey="date"
              stroke="#64748b"
              fontSize={10}
              fontFamily="JetBrains Mono"
              tickLine={false}
              axisLine={{ stroke: '#1F2636' }}
            />
            <YAxis
              stroke="#64748b"
              fontSize={10}
              fontFamily="JetBrains Mono"
              domain={[yDomainMin, yDomainMax]}
              tickFormatter={(v) => `₹${v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`}
              tickLine={false}
              axisLine={{ stroke: '#1F2636' }}
            />
            <Tooltip
              content={({ active, payload, label }) => {
                if (active && payload && payload.length) {
                  return (
                    <div className="bg-[#0A0C12] border border-white/[0.15] p-3 rounded-xl shadow-2xl text-xs space-y-1.5 font-mono">
                      <p className="font-bold text-slate-300 pb-1 border-b border-white/[0.08]">{label}</p>
                      {payload.map((entry: any) => (
                        <div key={entry.name} className="flex items-center justify-between gap-4">
                          <span className="flex items-center gap-1.5 font-medium" style={{ color: entry.color }}>
                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }}></span>
                            {entry.name === 'amazon' ? 'Amazon' : entry.name === 'flipkart' ? 'Flipkart' : 'BigBasket'}:
                          </span>
                          <span className="font-bold text-white">
                            {formatCurrency(entry.value)}
                          </span>
                        </div>
                      ))}
                    </div>
                  );
                }
                return null;
              }}
            />
            <Legend
              verticalAlign="top"
              align="right"
              iconType="circle"
              wrapperStyle={{ paddingBottom: '12px', fontSize: '11px', fontFamily: 'JetBrains Mono' }}
              formatter={(value) => {
                if (value === 'amazon') return <span className="text-amber-400 font-semibold">Amazon</span>;
                if (value === 'flipkart') return <span className="text-blue-400 font-semibold">Flipkart</span>;
                return <span className="text-[#C8F902] font-semibold">BigBasket</span>;
              }}
            />
            <Line
              type="monotone"
              dataKey="amazon"
              stroke="#FF9900"
              strokeWidth={2.5}
              dot={{ r: 3, fill: '#FF9900' }}
              activeDot={{ r: 6, stroke: '#fff', strokeWidth: 2 }}
              name="amazon"
            />
            <Line
              type="monotone"
              dataKey="flipkart"
              stroke="#2874F0"
              strokeWidth={2.5}
              dot={{ r: 3, fill: '#2874F0' }}
              activeDot={{ r: 6, stroke: '#fff', strokeWidth: 2 }}
              name="flipkart"
            />
            <Line
              type="monotone"
              dataKey="bigbasket"
              stroke="#C8F902"
              strokeWidth={2.5}
              dot={{ r: 3, fill: '#C8F902' }}
              activeDot={{ r: 6, stroke: '#fff', strokeWidth: 2 }}
              name="bigbasket"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-3 pt-3 border-t border-white/[0.08] flex items-center justify-between text-[10px] text-slate-500 font-mono">
        <span>* Scraped across certified Amazon, Flipkart, & BigBasket product nodes</span>
        <span>INDEX: INR (₹)</span>
      </div>
    </div>
  );
};
