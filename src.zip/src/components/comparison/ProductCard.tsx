import React, { useState } from 'react';
import { Product } from '../../types';
import { formatCurrency, VENDORS } from '../../utils/formatters';
import { PriceHistoryChart } from './PriceHistoryChart';
import {
  TrendingDown,
  Bell,
  Star,
  CheckCircle,
  XCircle,
  Truck,
  Award,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ArrowUpRight
} from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onSetAlert: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onSetAlert }) => {
  const [showHistory, setShowHistory] = useState(false);
  const [showSpecs, setShowSpecs] = useState(false);

  // Sort listings lowest to highest
  const sortedListings = [...product.listings].sort((a, b) => a.price - b.price);
  const cheapestVendorInfo = VENDORS[product.cheapestVendor];

  return (
    <div className="trading-card rounded-2xl sm:rounded-3xl overflow-hidden shadow-2xl hover:border-white/[0.15] transition-all duration-300">
      {/* Top Banner: Cheapest Deal Callout with QClay Neon Lime Badge */}
      <div className="bg-gradient-to-r from-[#C8F902]/10 via-[#0D1017] to-[#0A0C12] border-b border-white/[0.08] px-5 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-[#C8F902] text-[#08090C] shadow-glow-lime font-mono">
            <Award className="w-3.5 h-3.5 text-[#08090C]" />
            BEST BID ON {cheapestVendorInfo.name.toUpperCase()}
          </span>
          {product.savingsAmount > 0 && (
            <span className="text-xs font-mono font-semibold text-slate-300 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-[#C8F902]" />
              Save <strong className="text-[#C8F902] font-black">{formatCurrency(product.savingsAmount)}</strong> ({product.savingsPercent}% lower)
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onSetAlert(product)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-slate-200 border border-white/[0.1] transition-colors font-mono"
            title="Set Price Alert"
          >
            <Bell className="w-3.5 h-3.5 text-[#C8F902]" />
            <span>Set Alert</span>
          </button>

          <button
            onClick={() => setShowHistory(!showHistory)}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl border transition-all font-mono ${
              showHistory
                ? 'bg-[#C8F902]/15 text-[#C8F902] border-[#C8F902]/40 shadow-glow-lime'
                : 'bg-white/[0.05] hover:bg-white/[0.1] text-slate-300 border-white/[0.08]'
            }`}
          >
            <TrendingDown className="w-3.5 h-3.5" />
            <span>Trend Chart</span>
            {showHistory ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Product Info Section */}
      <div className="p-5 md:p-6 grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Product Image & Quick Meta */}
        <div className="md:col-span-4 flex flex-col items-center">
          <div className="w-full h-52 sm:h-56 rounded-2xl bg-[#06080C] border border-white/[0.06] p-4 flex items-center justify-center relative overflow-hidden group">
            <img
              src={product.imageUrl}
              alt={product.title}
              className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform duration-300"
              loading="lazy"
            />
            <div className="absolute top-3 left-3 bg-[#0D1017]/90 backdrop-blur-md px-2.5 py-0.5 rounded-md text-[10px] font-mono font-bold text-slate-300 border border-white/[0.1]">
              {product.brand.toUpperCase()}
            </div>
          </div>

          <div className="w-full mt-3 flex items-center justify-between text-xs text-slate-400 px-1 font-mono">
            <span className="flex items-center gap-1">
              <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <strong className="text-white">{product.averageRating}</strong> / 5.0
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-slate-400">{product.category}</span>
            <span className="text-slate-600">•</span>
            <button
              onClick={() => setShowSpecs(!showSpecs)}
              className="text-[#C8F902] hover:underline font-semibold"
            >
              {showSpecs ? 'Hide Specs' : 'Specs'}
            </button>
          </div>

          {/* Specifications Dropdown */}
          {showSpecs && (
            <div className="w-full mt-3 p-3.5 bg-[#06080C] rounded-xl border border-white/[0.08] text-xs space-y-1.5 animate-fadeIn font-mono">
              {Object.entries(product.specs).map(([key, val]) => (
                <div key={key} className="flex justify-between items-center text-slate-300">
                  <span className="text-slate-400 text-[11px]">{key}:</span>
                  <span className="font-semibold text-right ml-2 text-white text-[11px]">{val}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Comparison Listings Table / Matrix */}
        <div className="md:col-span-8 flex flex-col justify-between">
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight leading-snug">
              {product.title}
            </h3>
            <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
              {product.description}
            </p>
          </div>

          {/* Vendor Listings - Ranked lowest to highest */}
          <div className="mt-4 space-y-2.5">
            <div className="text-[10px] font-mono font-bold tracking-wider uppercase text-slate-400 flex justify-between px-2">
              <span>Vendor Match (Ranked Lowest Ask Price)</span>
              <span>Execute Order</span>
            </div>

            {sortedListings.map((listing, index) => {
              const vendor = VENDORS[listing.vendor];
              const isCheapest = index === 0;

              return (
                <div
                  key={listing.id}
                  className={`flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-2xl border transition-all ${
                    isCheapest
                      ? 'bg-gradient-to-r from-[#C8F902]/[0.07] via-[#0D1017] to-[#0A0C12] border-[#C8F902]/50 shadow-lg shadow-[#C8F902]/10 ring-1 ring-[#C8F902]/20'
                      : 'bg-[#080A0F] border-white/[0.06] hover:border-white/[0.12]'
                  }`}
                >
                  {/* Vendor Identity & Delivery info */}
                  <div className="flex items-center gap-3">
                    {/* Rank Number Badge */}
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-mono font-black ${
                        isCheapest
                          ? 'bg-[#C8F902] text-[#08090C] shadow-glow-lime'
                          : 'bg-[#141824] text-slate-400 border border-white/[0.08]'
                      }`}
                    >
                      #{index + 1}
                    </div>

                    {/* Vendor Badge */}
                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-xs font-bold px-2.5 py-0.5 rounded-md border font-mono ${
                            listing.vendor === 'amazon'
                              ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                              : listing.vendor === 'flipkart'
                              ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                              : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          }`}
                        >
                          {vendor.name}
                        </span>

                        {isCheapest && (
                          <span className="text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-[#C8F902] text-[#08090C] font-mono">
                            BEST DEAL
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1 font-mono">
                        <span className="flex items-center gap-1">
                          <Truck className="w-3 h-3 text-slate-400" />
                          {listing.deliveryDays}
                        </span>
                        <span className="text-slate-600">•</span>
                        <span>
                          {listing.inStock ? (
                            <span className="text-emerald-400 flex items-center gap-1">
                              <CheckCircle className="w-3 h-3" /> In Stock
                            </span>
                          ) : (
                            <span className="text-[#FF3B30] flex items-center gap-1">
                              <XCircle className="w-3 h-3" /> Out of Stock
                            </span>
                          )}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Price & Outbound Action Button */}
                  <div className="flex items-center justify-between sm:justify-end gap-4 mt-3 sm:mt-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-white/[0.06]">
                    <div className="text-right">
                      <div className="flex items-baseline justify-end gap-1.5 font-mono">
                        <span
                          className={`text-lg sm:text-xl font-black tracking-tight ${
                            isCheapest ? 'text-[#C8F902]' : 'text-white'
                          }`}
                        >
                          {formatCurrency(listing.price)}
                        </span>
                        {listing.originalPrice > listing.price && (
                          <span className="text-xs line-through text-slate-500">
                            {formatCurrency(listing.originalPrice)}
                          </span>
                        )}
                      </div>

                      {listing.discountPercent > 0 && (
                        <div className="text-[10px] text-[#C8F902] font-mono font-bold">
                          {listing.discountPercent}% OFF LIST
                        </div>
                      )}
                    </div>

                    {/* Outbound Link Button */}
                    <a
                      href={listing.productUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all ${
                        isCheapest
                          ? 'btn-lime'
                          : 'bg-[#141824] hover:bg-[#1a2030] text-slate-200 border border-white/[0.1] active:scale-95'
                      }`}
                      title={`Open product listing on ${vendor.name}`}
                    >
                      <span>Buy on {listing.vendor === 'amazon' ? 'Amazon' : listing.vendor === 'flipkart' ? 'Flipkart' : 'BigBasket'}</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Expandable Price History Chart Section */}
      {showHistory && (
        <div className="px-5 pb-6 border-t border-white/[0.08] pt-5 bg-[#06080C]/80">
          <PriceHistoryChart data={product.priceHistory} productTitle={product.title} />
        </div>
      )}
    </div>
  );
};
