import React from 'react';
import { X, CheckCircle, Shield, Globe, Zap } from 'lucide-react';

interface HelpGuideProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpGuide: React.FC<HelpGuideProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="trading-card rounded-3xl w-full max-w-2xl p-6 sm:p-7 shadow-2xl relative max-h-[90vh] overflow-y-auto border-white/[0.12]">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5 pb-4 border-b border-white/[0.08]">
          <div className="p-2.5 rounded-2xl bg-[#C8F902]/10 border border-[#C8F902]/20 text-[#C8F902]">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white tracking-tight uppercase font-mono">
              Architecture & Constraints Verification
            </h3>
            <p className="text-xs text-slate-400">
              DealPulse frontend engineering specifications & compliance matrix
            </p>
          </div>
        </div>

        <div className="space-y-6 text-xs text-slate-300">
          {/* 3-Step Flow Optimization */}
          <div className="p-4 rounded-2xl bg-[#06080C] border border-white/[0.08] space-y-3">
            <div className="flex items-center gap-2 font-mono">
              <span className="w-6 h-6 rounded-full bg-[#C8F902] text-[#08090C] font-black flex items-center justify-center text-xs">
                3
              </span>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                Optimized 3-Step User Flow (90% Target)
              </h4>
            </div>

            <p className="text-slate-400 leading-relaxed font-sans">
              Unlike legacy portals that require 6+ interactions across pages, DealPulse consolidates the purchase journey into 3 atomic steps:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 font-mono">
              <div className="p-3 rounded-xl bg-[#0D1017] border border-white/[0.06]">
                <span className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                  Step 1: Input Query
                </span>
                <p className="text-[11px] text-slate-400 font-sans">
                  User types query or clicks a popular pill. Empty inputs are caught immediately on client.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[#0D1017] border border-white/[0.06]">
                <span className="text-[10px] font-bold text-[#C8F902] uppercase block mb-1">
                  Step 2: Compare & Rank
                </span>
                <p className="text-[11px] text-slate-400 font-sans">
                  Products rank lowest price first across Amazon, Flipkart, & BigBasket with Best Deal badge.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[#0D1017] border border-white/[0.06]">
                <span className="text-[10px] font-bold text-white uppercase block mb-1">
                  Step 3: Direct Outbound
                </span>
                <p className="text-[11px] text-slate-400 font-sans">
                  1-click button launches vendor product listing directly in a secure new tab.
                </p>
              </div>
            </div>
          </div>

          {/* Security & Sanitization */}
          <div className="p-4 rounded-2xl bg-[#06080C] border border-white/[0.08] space-y-2.5">
            <div className="flex items-center gap-2 font-mono">
              <Shield className="w-4 h-4 text-[#C8F902]" />
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                SQL Injection Prevention & Shielding
              </h4>
            </div>
            <p className="text-slate-400 leading-relaxed font-sans">
              Inputs are actively filtered via security regex patterns stripping <code className="text-[#C8F902]">' OR 1=1</code>, <code className="text-[#C8F902]">UNION SELECT</code>, <code className="text-[#C8F902]">DROP TABLE</code>, <code className="text-[#C8F902]">--</code>, and <code className="text-[#C8F902]">;</code>. Errors shield database internals.
            </p>
          </div>

          {/* Cross-Browser Support */}
          <div className="p-4 rounded-2xl bg-[#06080C] border border-white/[0.08] space-y-2.5">
            <div className="flex items-center gap-2 font-mono">
              <Globe className="w-4 h-4 text-white" />
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                Cross-Browser Compatibility
              </h4>
            </div>
            <p className="text-slate-400 leading-relaxed font-sans">
              Constructed with standard modern CSS Flexbox/Grid and Web APIs tested to work identically across Google Chrome, Microsoft Edge, and Mozilla Firefox.
            </p>
          </div>

          {/* 5-Attempt Lockout */}
          <div className="p-4 rounded-2xl bg-[#06080C] border border-white/[0.08] space-y-2.5">
            <div className="flex items-center gap-2 font-mono">
              <CheckCircle className="w-4 h-4 text-[#FF3B30]" />
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                5-Attempt Account Lockout Security
              </h4>
            </div>
            <p className="text-slate-400 leading-relaxed font-sans">
              Unsuccessful authentication attempts are stored in persistent state. Reaching 5 consecutive failures triggers a mandatory 60-second lockout timer, disabling inputs and displaying clear warnings.
            </p>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-white/[0.08] flex justify-end font-mono">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl btn-lime text-xs font-mono uppercase tracking-wider"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
