import React, { useState, useEffect } from 'react';
import { LockoutState } from '../../types';
import {
  Lock,
  Mail,
  User as UserIcon,
  X,
  AlertTriangle,
  ShieldAlert,
  Zap,
  RotateCcw
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (email: string, pass: string) => Promise<void>;
  onRegister: (name: string, email: string, pass: string, role?: 'user' | 'admin') => Promise<void>;
  lockoutState: LockoutState;
  onSimulateLockout: () => void;
  onResetLockout: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLogin,
  onRegister,
  lockoutState,
  onSimulateLockout,
  onResetLockout
}) => {
  if (!isOpen) return null;

  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<'user' | 'admin'>('user');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(0);

  // Countdown timer for lockout
  useEffect(() => {
    if (!lockoutState.isLocked || !lockoutState.lockedUntil) {
      setSecondsRemaining(0);
      return;
    }

    const interval = setInterval(() => {
      const diff = Math.max(0, Math.ceil((lockoutState.lockedUntil! - Date.now()) / 1000));
      setSecondsRemaining(diff);
      if (diff <= 0) {
        clearInterval(interval);
        onResetLockout();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [lockoutState, onResetLockout]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (lockoutState.isLocked) {
      setError(`Account locked. Please wait ${secondsRemaining}s before attempting again.`);
      return;
    }

    if (!email || !email.includes('@')) {
      setError('Please provide a valid email address.');
      return;
    }

    if (mode === 'register' && !name.trim()) {
      setError('Please provide your full name.');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (mode === 'login') {
        await onLogin(email, password);
      } else {
        await onRegister(name, email, password, role);
      }
      onClose();
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAutofill = (type: 'user' | 'admin') => {
    setError(null);
    if (type === 'admin') {
      setEmail('admin@dealpulse.com');
      setPassword('admin123');
    } else {
      setEmail('user@example.com');
      setPassword('user123');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="trading-card rounded-3xl w-full max-w-md p-6 sm:p-7 shadow-2xl relative border-white/[0.12]">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Tabs */}
        <div className="flex items-center gap-3 border-b border-white/[0.08] pb-4 mb-5">
          <div className="p-2.5 rounded-2xl bg-[#C8F902]/10 border border-[#C8F902]/20 text-[#C8F902]">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <div className="flex gap-4 font-mono">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError(null);
                }}
                className={`text-base font-bold transition-colors uppercase ${
                  mode === 'login' ? 'text-white border-b-2 border-[#C8F902] pb-1' : 'text-slate-400 hover:text-slate-300'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setError(null);
                }}
                className={`text-base font-bold transition-colors uppercase ${
                  mode === 'register' ? 'text-white border-b-2 border-[#C8F902] pb-1' : 'text-slate-400 hover:text-slate-300'
                }`}
              >
                Create Account
              </button>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {mode === 'login'
                ? 'Sign in to access price alerts and search history'
                : 'Register a new account on DealPulse'}
            </p>
          </div>
        </div>

        {/* Lockout Warning Banner (Active after 5 failed attempts) */}
        {lockoutState.isLocked ? (
          <div className="mb-5 p-4 rounded-2xl bg-[#FF3B30]/10 border border-[#FF3B30]/40 shadow-glow-coral text-white space-y-2 animate-fadeIn font-mono">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-[#FF3B30] flex-shrink-0" />
                <strong className="text-xs font-bold uppercase tracking-wider text-[#FF3B30]">
                  Account Locked (5 Attempts)
                </strong>
              </div>
              <span className="text-xs font-black px-2 py-0.5 rounded bg-[#FF3B30]/20 text-[#FF3B30] border border-[#FF3B30]/30">
                {secondsRemaining}s
              </span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed font-sans">
              For security compliance, this account has been temporarily locked after 5 consecutive unsuccessful attempts. Inputs are disabled.
            </p>
            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={onResetLockout}
                className="text-xs text-[#C8F902] hover:underline font-bold flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Simulate Emergency Unlock</span>
              </button>
            </div>
          </div>
        ) : lockoutState.failedAttempts > 0 ? (
          <div className="mb-4 p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-300 text-xs flex items-center justify-between font-mono">
            <span className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>
                Failed Attempts: <strong>{lockoutState.failedAttempts} / 5</strong> before lockout
              </span>
            </span>
            <button
              onClick={onResetLockout}
              className="text-[10px] underline text-amber-400 hover:text-amber-200"
            >
              Reset
            </button>
          </div>
        ) : null}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'register' && (
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1 uppercase tracking-wider font-mono">
                Full Name
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={name}
                  disabled={lockoutState.isLocked}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. John Doe"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#06080C] border border-white/[0.08] text-white text-xs focus:border-[#C8F902] disabled:opacity-40"
                />
              </div>
            </div>
          )}

          <div>
            <label className="text-[11px] font-bold text-slate-300 block mb-1 uppercase tracking-wider font-mono">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="email"
                value={email}
                disabled={lockoutState.isLocked}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="trader@example.com"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#06080C] border border-white/[0.08] text-white text-xs focus:border-[#C8F902] disabled:opacity-40 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-300 block mb-1 uppercase tracking-wider font-mono">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="password"
                value={password}
                disabled={lockoutState.isLocked}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#06080C] border border-white/[0.08] text-white text-xs focus:border-[#C8F902] disabled:opacity-40 font-mono"
              />
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1 uppercase tracking-wider font-mono">
                Account Role
              </label>
              <div className="grid grid-cols-2 gap-2 font-mono">
                <button
                  type="button"
                  onClick={() => setRole('user')}
                  className={`py-2 rounded-xl text-xs font-semibold border transition-all ${
                    role === 'user'
                      ? 'bg-[#C8F902]/15 text-[#C8F902] border-[#C8F902]/50 font-bold'
                      : 'bg-[#06080C] text-slate-400 border-white/[0.08]'
                  }`}
                >
                  Standard Shopper
                </button>
                <button
                  type="button"
                  onClick={() => setRole('admin')}
                  className={`py-2 rounded-xl text-xs font-semibold border transition-all ${
                    role === 'admin'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500'
                      : 'bg-[#06080C] text-slate-400 border-white/[0.08]'
                  }`}
                >
                  Administrator
                </button>
              </div>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="p-3 rounded-xl bg-[#FF3B30]/10 border border-[#FF3B30]/30 text-[#FF3B30] text-xs flex items-center gap-2 font-mono">
              <AlertTriangle className="w-4 h-4 text-[#FF3B30] flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting || lockoutState.isLocked}
            className="w-full py-3 rounded-xl btn-lime text-xs font-mono uppercase tracking-wider disabled:opacity-40"
          >
            {isSubmitting
              ? 'Verifying...'
              : lockoutState.isLocked
              ? `Account Locked (${secondsRemaining}s)`
              : mode === 'login'
              ? 'Authenticate & Enter'
              : 'Create My Account'}
          </button>
        </form>

        {/* Demo Helpers for Quick Reviewing */}
        <div className="mt-5 pt-4 border-t border-white/[0.08] space-y-2 font-mono">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Reviewer Demo Controls
          </span>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              type="button"
              onClick={() => handleAutofill('user')}
              className="p-2.5 rounded-xl bg-[#06080C] hover:bg-[#121622] text-slate-300 border border-white/[0.08] transition-colors text-left"
            >
              <span className="font-bold block text-[#C8F902] text-[11px]">Fill User</span>
              <span className="text-[10px] text-slate-500">user@example.com</span>
            </button>

            <button
              type="button"
              onClick={() => handleAutofill('admin')}
              className="p-2.5 rounded-xl bg-[#06080C] hover:bg-[#121622] text-slate-300 border border-white/[0.08] transition-colors text-left"
            >
              <span className="font-bold block text-amber-400 text-[11px]">Fill Admin</span>
              <span className="text-[10px] text-slate-500">admin@dealpulse.com</span>
            </button>
          </div>

          <button
            type="button"
            onClick={onSimulateLockout}
            className="w-full mt-2 py-2 px-3 rounded-xl text-xs font-semibold bg-[#FF3B30]/10 hover:bg-[#FF3B30]/20 text-[#FF3B30] border border-[#FF3B30]/30 flex items-center justify-center gap-1.5 transition-colors"
          >
            <Zap className="w-3.5 h-3.5 text-[#FF3B30]" />
            <span>Simulate 5 Failed Logins (Trigger Lockout)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
