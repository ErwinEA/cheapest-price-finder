import React, { useState } from 'react';
import { ScrapingJob, ScrapingLog, SiteSelectorConfig, User, VendorId } from '../../types';
import { formatExactDateTime, VENDORS } from '../../utils/formatters';
import {
  ShieldAlert,
  Activity,
  Sliders,
  Play,
  CheckCircle2,
  XCircle,
  Clock,
  Save,
  Code,
  Terminal,
  Cpu,
  RefreshCw
} from 'lucide-react';

interface AdminPanelProps {
  currentUser: User | null;
  onSwitchToAdmin: () => void;
  jobs: ScrapingJob[];
  logs: ScrapingLog[];
  configs: SiteSelectorConfig[];
  onTriggerScrape: (vendor: VendorId) => void;
  onUpdateConfig: (config: SiteSelectorConfig) => void;
  onClearLogs: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  currentUser,
  onSwitchToAdmin,
  jobs,
  logs,
  configs,
  onTriggerScrape,
  onUpdateConfig,
  onClearLogs
}) => {
  const [activeTab, setActiveTab] = useState<'jobs' | 'logs' | 'selectors'>('jobs');
  const [selectedVendorConfig, setSelectedVendorConfig] = useState<VendorId>('amazon');
  const [logFilter, setLogFilter] = useState<'ALL' | 'ERROR' | 'WARN' | 'SUCCESS' | 'INFO'>('ALL');
  
  // Selector tester state
  const [testSelectorInput, setTestSelectorInput] = useState<string>('div.Nx9bqj');
  const [testHtmlInput, setTestHtmlInput] = useState<string>(
    `<div class="cPHDOP"><div class="KzDlHZ">Apple iPhone 15 (Black, 128 GB)</div><div class="Nx9bqj">₹65,999</div><div class="yRaY8j">₹79,900</div><div class="XQDdHH">4.6 ★</div></div>`
  );
  const [testResult, setTestResult] = useState<{ matches: number; extract: string } | null>(null);

  // Editable config state
  const currentConfig = configs.find(c => c.vendor === selectedVendorConfig) || configs[0];
  const [editableConfig, setEditableConfig] = useState<SiteSelectorConfig>(currentConfig);

  // Sync when selected vendor tab changes
  const handleVendorTabChange = (vendor: VendorId) => {
    setSelectedVendorConfig(vendor);
    const found = configs.find(c => c.vendor === vendor);
    if (found) {
      setEditableConfig(found);
      setTestSelectorInput(found.selectors.price);
      setTestResult(null);
    }
  };

  // Role Access Restriction Guard
  if (!currentUser || currentUser.role !== 'admin') {
    return (
      <div className="trading-card rounded-3xl p-10 max-w-xl mx-auto text-center shadow-2xl">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-[#FF3B30]/10 border border-[#FF3B30]/20 flex items-center justify-center text-[#FF3B30] mb-5">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <span className="text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-full bg-[#FF3B30]/20 text-[#FF3B30] border border-[#FF3B30]/30 font-mono">
          ROLE RESTRICTED (403 FORBIDDEN)
        </span>
        <h2 className="text-xl font-bold text-white mt-3 font-mono">Administrator Access Required</h2>
        <p className="text-xs text-slate-400 mt-2 leading-relaxed">
          The Scraping Engine Monitor, selector rule compilers, and crawler pool logs are restricted exclusively to administrators.
        </p>

        <div className="mt-6 pt-5 border-t border-white/[0.08]">
          <button
            onClick={onSwitchToAdmin}
            className="w-full py-3 rounded-xl btn-lime text-xs font-mono uppercase tracking-wider"
          >
            Authenticate as Administrator (admin@dealpulse.com)
          </button>
          <p className="text-[10px] text-slate-500 font-mono mt-2">
            Click above to simulate logging in as an administrator for instant review.
          </p>
        </div>
      </div>
    );
  }

  // Filter logs
  const filteredLogs = logs.filter(log => logFilter === 'ALL' || log.level === logFilter);

  // Calculate quick stats
  const runningJobs = jobs.filter(j => j.status === 'running').length;
  const totalScraped = jobs.reduce((acc, j) => acc + j.itemsScraped, 0);
  const failedJobs = jobs.filter(j => j.status === 'failed').length;

  const handleTestSelector = () => {
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(testHtmlInput, 'text/html');
      const elements = doc.querySelectorAll(testSelectorInput);
      const extract = elements.length > 0 ? (elements[0].textContent?.trim() || elements[0].outerHTML) : 'No elements found';
      setTestResult({
        matches: elements.length,
        extract
      });
    } catch (err) {
      setTestResult({
        matches: 0,
        extract: 'Selector error: ' + (err as Error).message
      });
    }
  };

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateConfig(editableConfig);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Admin Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-[#C8F902]/10 border border-[#C8F902]/20 text-[#C8F902]">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-white tracking-tight uppercase font-mono">
                  Scraper Engine & Selector Console
                </h2>
                <span className="text-[9px] font-black px-2 py-0.5 rounded bg-[#C8F902] text-[#08090C] font-mono">
                  ADMIN HUD
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Monitor live crawler workers across Amazon, Flipkart, & BigBasket, inspect logs, and tune DOM selectors.
              </p>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center p-1 bg-[#0D1017] border border-white/[0.08] rounded-xl font-mono">
          <button
            onClick={() => setActiveTab('jobs')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'jobs'
                ? 'bg-[#181D2A] text-[#C8F902] border border-white/[0.1] shadow-sm font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Jobs ({jobs.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('logs')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'logs'
                ? 'bg-[#181D2A] text-[#C8F902] border border-white/[0.1] shadow-sm font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Logs ({logs.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('selectors')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'selectors'
                ? 'bg-[#181D2A] text-[#C8F902] border border-white/[0.1] shadow-sm font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Selectors</span>
          </button>
        </div>
      </div>

      {/* TAB 1: SCRAPING JOBS MONITOR */}
      {activeTab === 'jobs' && (
        <div className="space-y-6">
          {/* Quick Metrics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl trading-card font-mono">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Active Crawler Nodes
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-white">{runningJobs}</span>
                <span className="text-xs text-[#C8F902] font-bold">WORKERS LIVE</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl trading-card font-mono">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Total Ingested Today
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-[#C8F902]">
                  {totalScraped.toLocaleString('en-IN')}
                </span>
                <span className="text-xs text-slate-400">SKUs</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl trading-card font-mono">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Error / Retry Flag
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-[#FF3B30]">{failedJobs}</span>
                <span className="text-xs text-slate-400">EXCEPTIONS</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl trading-card font-mono">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Target Marketplaces
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-white">3 Vendors</span>
                <span className="text-xs text-slate-400">AMZ • FK • BB</span>
              </div>
            </div>
          </div>

          {/* Jobs Table */}
          <div className="trading-card rounded-2xl sm:rounded-3xl overflow-hidden shadow-2xl">
            <div className="px-5 py-4 border-b border-white/[0.08] flex items-center justify-between font-mono">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Worker Pool Execution Matrix
              </h3>
              <span className="text-[11px] text-slate-400">
                Backoff Policy: Exponential (3 max retries)
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs font-mono">
                <thead>
                  <tr className="border-b border-white/[0.08] bg-[#06080C] text-slate-400 uppercase tracking-wider text-[10px]">
                    <th className="py-3.5 px-4">Vendor</th>
                    <th className="py-3.5 px-4">Catalog Target</th>
                    <th className="py-3.5 px-4">Status</th>
                    <th className="py-3.5 px-4">Scraped SKUs</th>
                    <th className="py-3.5 px-4">Retries</th>
                    <th className="py-3.5 px-4">Timestamp</th>
                    <th className="py-3.5 px-4 text-right">Trigger</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.06]">
                  {jobs.map((job) => {
                    const vendor = VENDORS[job.vendor];
                    return (
                      <tr key={job.id} className="hover:bg-white/[0.02] transition-colors">
                        <td className="py-3.5 px-4 font-semibold text-white">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                              job.vendor === 'amazon'
                                ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                                : job.vendor === 'flipkart'
                                ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                                : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                            }`}
                          >
                            {vendor.name}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-slate-300 font-sans font-medium">
                          {job.targetCategory}
                        </td>
                        <td className="py-3.5 px-4">
                          {job.status === 'running' && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#C8F902]/15 text-[#C8F902] border border-[#C8F902]/30 animate-pulse">
                              <RefreshCw className="w-3 h-3 animate-spin" />
                              RUNNING
                            </span>
                          )}
                          {job.status === 'completed' && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                              <CheckCircle2 className="w-3 h-3" />
                              COMPLETED
                            </span>
                          )}
                          {job.status === 'failed' && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#FF3B30]/20 text-[#FF3B30] border border-[#FF3B30]/30">
                              <XCircle className="w-3 h-3" />
                              FAILED
                            </span>
                          )}
                          {job.status === 'scheduled' && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#141824] text-slate-400 border border-white/[0.08]">
                              <Clock className="w-3 h-3" />
                              SCHEDULED
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 font-bold text-white">
                          {job.itemsScraped.toLocaleString('en-IN')}
                        </td>
                        <td className="py-3.5 px-4">
                          <span
                            className={
                              job.retryCount > 0
                                ? 'text-amber-400 font-bold'
                                : 'text-slate-500'
                            }
                          >
                            {job.retryCount} / {job.maxRetries}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-slate-500 text-[11px]">
                          {formatExactDateTime(job.startedAt)}
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <button
                            onClick={() => onTriggerScrape(job.vendor)}
                            disabled={job.status === 'running'}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-[#141824] hover:bg-[#1f2636] text-white border border-white/[0.1] transition-colors disabled:opacity-40"
                          >
                            <Play className="w-3 h-3 text-[#C8F902]" />
                            <span>Trigger</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SCRAPER LOGS & REPORTS */}
      {activeTab === 'logs' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 font-mono">
            {/* Filter buttons */}
            <div className="flex items-center gap-2">
              {(['ALL', 'ERROR', 'WARN', 'SUCCESS', 'INFO'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setLogFilter(filter)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold border transition-all ${
                    logFilter === filter
                      ? 'bg-[#C8F902] text-[#08090C] border-[#C8F902] font-bold shadow-glow-lime'
                      : 'bg-[#0D1017] text-slate-400 border-white/[0.08] hover:border-white/[0.15]'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>

            <button
              onClick={onClearLogs}
              className="text-xs text-slate-400 hover:text-[#FF3B30] transition-colors"
            >
              Clear Logs
            </button>
          </div>

          <div className="bg-[#06080C] border border-white/[0.08] rounded-2xl p-4 font-mono text-xs max-h-[500px] overflow-y-auto space-y-2.5">
            {filteredLogs.length === 0 ? (
              <p className="text-slate-500 text-center py-8">No log entries matching selected severity.</p>
            ) : (
              filteredLogs.map((log) => {
                const vendor = VENDORS[log.vendor];
                return (
                  <div
                    key={log.id}
                    className="p-2.5 rounded-xl bg-[#0D1017] border border-white/[0.06] flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div className="flex items-start gap-2.5">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[9px] font-black ${
                          log.level === 'ERROR'
                            ? 'bg-[#FF3B30]/20 text-[#FF3B30]'
                            : log.level === 'WARN'
                            ? 'bg-amber-500/20 text-amber-300'
                            : log.level === 'SUCCESS'
                            ? 'bg-[#C8F902]/20 text-[#C8F902]'
                            : 'bg-blue-500/20 text-blue-300'
                        }`}
                      >
                        [{log.level}]
                      </span>

                      <div>
                        <span className="text-slate-300 font-sans font-medium">{log.message}</span>
                        {log.selectorTested && (
                          <div className="text-[10px] text-slate-500 mt-0.5">
                            Selector: <code className="text-[#C8F902]">{log.selectorTested}</code>
                          </div>
                        )}
                        {log.endpoint && (
                          <div className="text-[10px] text-slate-500 mt-0.5">
                            Endpoint: <span className="text-slate-300">{log.endpoint}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="text-right text-[10px] text-slate-500 whitespace-nowrap self-end sm:self-center font-mono">
                      <span className="mr-2 text-slate-300 font-bold">{vendor.name}</span>
                      <span>{formatExactDateTime(log.timestamp)}</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* TAB 3: SITE SELECTORS & LIVE TESTER */}
      {activeTab === 'selectors' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Vendor Selector Config Form */}
          <div className="lg:col-span-7 space-y-4">
            {/* Vendor Tabs */}
            <div className="flex gap-2 font-mono">
              {(['amazon', 'flipkart', 'bigbasket'] as VendorId[]).map((vid) => {
                const v = VENDORS[vid];
                return (
                  <button
                    key={vid}
                    onClick={() => handleVendorTabChange(vid)}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${
                      selectedVendorConfig === vid
                        ? 'bg-[#141824] text-[#C8F902] border-[#C8F902]/50 shadow-glow-lime'
                        : 'bg-[#0D1017] text-slate-400 border-white/[0.08]'
                    }`}
                  >
                    {v.name}
                  </button>
                );
              })}
            </div>

            <form onSubmit={handleSaveConfig} className="trading-card rounded-2xl p-5 space-y-4 shadow-xl">
              <div className="flex items-center justify-between pb-3 border-b border-white/[0.08] font-mono">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  {editableConfig.vendorName} CSS Extraction Rules
                </h4>
                <span className="text-[10px] text-slate-500">
                  Updated: {editableConfig.lastUpdated}
                </span>
              </div>

              {/* Base URL and User Agent */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Base URL
                  </label>
                  <input
                    type="text"
                    value={editableConfig.baseUrl}
                    onChange={(e) => setEditableConfig({ ...editableConfig, baseUrl: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-[#06080C] border border-white/[0.08] text-white focus:border-[#C8F902]"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Request Delay (ms)
                  </label>
                  <input
                    type="number"
                    value={editableConfig.requestDelayMs}
                    onChange={(e) => setEditableConfig({ ...editableConfig, requestDelayMs: Number(e.target.value) })}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-[#06080C] border border-white/[0.08] text-white focus:border-[#C8F902]"
                  />
                </div>
              </div>

              {/* Selector Inputs */}
              <div className="space-y-3 pt-2 font-mono">
                <label className="text-[10px] font-bold text-slate-300 block uppercase tracking-wider">
                  DOM Extraction Selectors
                </label>

                {[
                  { key: 'container' as const, label: 'Card Container' },
                  { key: 'title' as const, label: 'Title Selector' },
                  { key: 'price' as const, label: 'Current Price' },
                  { key: 'originalPrice' as const, label: 'Original MRP' },
                  { key: 'rating' as const, label: 'Rating Selector' },
                  { key: 'inStock' as const, label: 'In-Stock Button' },
                  { key: 'imageUrl' as const, label: 'Image URL' }
                ].map(({ key, label }) => (
                  <div key={key}>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[10px] text-slate-400">{label}:</span>
                      <button
                        type="button"
                        onClick={() => setTestSelectorInput(editableConfig.selectors[key])}
                        className="text-[10px] text-[#C8F902] hover:underline"
                      >
                        Copy to Tester
                      </button>
                    </div>
                    <input
                      type="text"
                      value={editableConfig.selectors[key]}
                      onChange={(e) =>
                        setEditableConfig({
                          ...editableConfig,
                          selectors: {
                            ...editableConfig.selectors,
                            [key]: e.target.value
                          }
                        })
                      }
                      className="w-full px-3 py-1.5 text-xs rounded-xl bg-[#06080C] border border-white/[0.08] text-white focus:border-[#C8F902]"
                    />
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t border-white/[0.08] flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl btn-lime text-xs font-mono uppercase tracking-wider flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Selector Configuration</span>
                </button>
              </div>
            </form>
          </div>

          {/* Interactive Live Selector Tester Simulator */}
          <div className="lg:col-span-5 space-y-4">
            <div className="trading-card rounded-2xl p-5 shadow-xl space-y-4 font-mono">
              <div className="flex items-center gap-2 pb-3 border-b border-white/[0.08]">
                <Code className="w-4 h-4 text-[#C8F902]" />
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  Interactive Selector Simulator
                </h4>
              </div>

              <p className="text-xs text-slate-400 font-sans">
                Test CSS selectors against live HTML markup snippets to verify DOM query resolution prior to publishing rules.
              </p>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Target CSS Selector
                </label>
                <input
                  type="text"
                  value={testSelectorInput}
                  onChange={(e) => setTestSelectorInput(e.target.value)}
                  placeholder="e.g. div.Nx9bqj or .a-price-whole"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-[#06080C] border border-white/[0.12] text-[#C8F902] focus:border-[#C8F902]"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Sample Vendor HTML Snippet
                </label>
                <textarea
                  rows={5}
                  value={testHtmlInput}
                  onChange={(e) => setTestHtmlInput(e.target.value)}
                  className="w-full p-2.5 text-[11px] rounded-xl bg-[#06080C] border border-white/[0.08] text-slate-300 focus:border-[#C8F902]"
                />
              </div>

              <button
                type="button"
                onClick={handleTestSelector}
                className="w-full py-2.5 rounded-xl btn-lime text-xs uppercase tracking-wider flex items-center justify-center gap-2"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Execute Selector Test</span>
              </button>

              {/* Test Result Display */}
              {testResult && (
                <div className="p-3.5 rounded-xl bg-[#06080C] border border-white/[0.08] space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-300">Resolution Result:</span>
                    <span
                      className={`font-black px-2 py-0.5 rounded text-[10px] ${
                        testResult.matches > 0
                          ? 'bg-[#C8F902]/20 text-[#C8F902] border border-[#C8F902]/40'
                          : 'bg-[#FF3B30]/20 text-[#FF3B30] border border-[#FF3B30]/40'
                      }`}
                    >
                      {testResult.matches} match{testResult.matches === 1 ? '' : 'es'}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block">Extracted Output:</span>
                    <div className="p-2 rounded bg-[#0D1017] border border-white/[0.08] text-xs text-white break-words mt-1">
                      {testResult.extract}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
