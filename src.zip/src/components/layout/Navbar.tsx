import React, { useState } from 'react';
import { User } from '../../types';
import {
  Tag,
  Search,
  History,
  Bell,
  Shield,
  LogOut,
  LogIn,
  Menu,
  X,
  Activity,
  ArrowUpRight
} from 'lucide-react';

interface NavbarProps {
  currentTab: 'search' | 'history' | 'alerts' | 'admin';
  onSelectTab: (tab: 'search' | 'history' | 'alerts' | 'admin') => void;
  currentUser: User | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  onFastRoleToggle: () => void;
  activeAlertsCount: number;
  onOpenFlowGuide: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  currentUser,
  onOpenAuth,
  onLogout,
  onFastRoleToggle,
  activeAlertsCount,
  onOpenFlowGuide
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'search' as const, label: 'Search & Match', icon: Search },
    { id: 'alerts' as const, label: 'Price Alerts', icon: Bell, badge: activeAlertsCount },
    { id: 'history' as const, label: 'Audit History', icon: History },
    { id: 'admin' as const, label: 'Scraper Engine', icon: Shield, adminOnly: true }
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/[0.08] bg-[#08090C]/90 backdrop-blur-2xl">
      {/* Top Trading Platform Ticker Bar */}
      <div className="bg-[#050608] border-b border-white/[0.05] py-1.5 px-4 text-[11px] text-slate-400 font-mono flex items-center justify-between gap-4 overflow-x-auto">
        <div className="flex items-center gap-4 flex-shrink-0">
          <div className="flex items-center gap-2 text-white">
            <span className="w-2 h-2 rounded-full bg-[#C8F902] neon-dot"></span>
            <span className="font-bold tracking-wider text-[10px] uppercase text-[#C8F902]">LIVE DEAL FEED</span>
          </div>
          <span className="text-slate-600 hidden sm:inline">|</span>
          <div className="hidden sm:flex items-center gap-3 text-slate-300">
            <span>AMAZON <strong className="text-white">LIVE</strong></span>
            <span>FLIPKART <strong className="text-white">LIVE</strong></span>
            <span>BIGBASKET <strong className="text-white">LIVE</strong></span>
          </div>
        </div>

        <div className="flex items-center gap-3 text-slate-400 text-[11px] flex-shrink-0">
          <span className="hidden md:inline font-sans text-slate-400">
            3-Step Lowest Price Guarantee: Search &rarr; Spot Best Deal &rarr; Buy Direct
          </span>
          <button
            onClick={onOpenFlowGuide}
            className="text-[#C8F902] hover:underline font-bold flex items-center gap-0.5"
          >
            <span>Specs & Guide</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand Logo - High-End Trading Aesthetic */}
        <div
          onClick={() => onSelectTab('search')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-[#C8F902] flex items-center justify-center shadow-glow-lime group-hover:scale-105 transition-transform duration-200">
            <Tag className="w-5 h-5 text-[#08090C] font-black" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base tracking-tight text-white font-sans uppercase">
                DealPulse
              </span>
              <span className="text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#C8F902]/15 text-[#C8F902] border border-[#C8F902]/30">
                PRO FINDER
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono -mt-0.5 tracking-wider">
              AMAZON • FLIPKART • BIGBASKET
            </p>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1.5 p-1 rounded-2xl bg-[#0D1017] border border-white/[0.08]">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all duration-200 relative ${
                  isActive
                    ? 'bg-[#181D2A] text-white shadow-sm border border-white/[0.12]'
                    : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#C8F902]' : 'text-slate-400'}`} />
                <span>{item.label}</span>

                {/* Badge count */}
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="w-4 h-4 rounded-full bg-[#C8F902] text-[#08090C] text-[9px] font-black flex items-center justify-center">
                    {item.badge}
                  </span>
                )}

                {item.adminOnly && (
                  <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    Admin
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Section: Role Switcher & Auth */}
        <div className="flex items-center gap-3">
          {/* Fast Role Switcher Pill for Evaluators */}
          {currentUser && (
            <button
              onClick={onFastRoleToggle}
              className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl text-[11px] font-mono font-bold border transition-all ${
                currentUser.role === 'admin'
                  ? 'bg-amber-500/10 text-amber-400 border-amber-500/30 hover:bg-amber-500/20'
                  : 'bg-[#C8F902]/10 text-[#C8F902] border-[#C8F902]/30 hover:bg-[#C8F902]/20'
              }`}
              title="Click to toggle between Standard User and Admin permissions instantly"
            >
              <Activity className="w-3.5 h-3.5" />
              <span>ROLE: {currentUser.role === 'admin' ? 'ADMIN' : 'SHOPPER'}</span>
              <span className="text-[10px] opacity-75 underline">(SWITCH)</span>
            </button>
          )}

          {/* User Profile / Auth State */}
          {currentUser ? (
            <div className="flex items-center gap-2.5">
              <div className="hidden lg:flex flex-col text-right">
                <span className="text-xs font-bold text-white leading-tight">{currentUser.name}</span>
                <span className="text-[10px] text-slate-400 font-mono truncate max-w-[130px]">{currentUser.email}</span>
              </div>

              <button
                onClick={onLogout}
                className="p-2 rounded-xl text-slate-400 hover:text-[#FF3B30] hover:bg-[#FF3B30]/10 border border-white/[0.08] transition-colors"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold btn-lime"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>
          )}

          {/* Mobile menu toggle button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-xl text-slate-400 hover:text-white border border-white/[0.08]"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-white/[0.08] bg-[#08090C] px-4 pt-3 pb-5 space-y-2 animate-fadeIn">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between p-3 rounded-xl text-xs font-semibold ${
                  isActive
                    ? 'bg-[#141824] text-white border border-white/[0.1]'
                    : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#C8F902]' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.adminOnly && (
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">
                    Admin
                  </span>
                )}
              </button>
            );
          })}

          {currentUser && (
            <div className="pt-3 border-t border-white/[0.08] flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400">ROLE: {currentUser.role.toUpperCase()}</span>
              <button
                onClick={onFastRoleToggle}
                className="text-[#C8F902] hover:underline font-bold"
              >
                Switch Role
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
