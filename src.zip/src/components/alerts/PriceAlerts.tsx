import React from 'react';
import { PriceAlert } from '../../types';
import { formatCurrency, formatRelativeTime, VENDORS } from '../../utils/formatters';
import {
  Bell,
  Trash2,
  CheckCircle2,
  Clock,
  Zap,
  Mail,
  Smartphone
} from 'lucide-react';

interface PriceAlertsProps {
  alerts: PriceAlert[];
  onDeleteAlert: (id: string) => void;
  onSimulatePriceDrop: (id: string) => void;
  onOpenSearch: () => void;
}

export const PriceAlerts: React.FC<PriceAlertsProps> = ({
  alerts,
  onDeleteAlert,
  onSimulatePriceDrop,
  onOpenSearch
}) => {
  if (alerts.length === 0) {
    return (
      <div className="trading-card rounded-3xl p-12 text-center max-w-2xl mx-auto shadow-2xl">
        <div className="w-14 h-14 mx-auto rounded-2xl bg-[#C8F902]/10 border border-[#C8F902]/20 flex items-center justify-center text-[#C8F902] mb-4">
          <Bell className="w-7 h-7" />
        </div>
        <h3 className="text-lg font-bold text-white uppercase tracking-wider font-mono">No Active Target Triggers</h3>
        <p className="text-xs text-slate-400 mt-1.5 max-w-md mx-auto leading-relaxed">
          Set automated limits for high-demand electronics or groceries across Amazon, Flipkart, and BigBasket. When any vendor dips below your price trigger, you will be notified immediately.
        </p>
        <button
          onClick={onOpenSearch}
          className="mt-5 px-5 py-2.5 rounded-xl text-xs font-mono font-bold btn-lime"
        >
          Browse Assets to Track
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-[#C8F902]" />
            <h2 className="text-xl font-black text-white tracking-tight uppercase font-mono">
              Automated Price Triggers
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time price feed monitor tracking minimum quotes against your target threshold.
          </p>
        </div>

        <div className="text-xs text-slate-400 bg-[#0D1017] px-3.5 py-1.5 rounded-xl border border-white/[0.08] flex items-center gap-2 font-mono">
          <span className="w-2 h-2 rounded-full bg-[#C8F902] neon-dot"></span>
          <span>POLLING SCAPER ENGINE EVERY 15M</span>
        </div>
      </div>

      {/* Alerts Grid */}
      <div className="grid grid-cols-1 gap-4">
        {alerts.map((alert) => {
          const vendor = VENDORS[alert.cheapestVendor];
          const isTriggered = alert.status === 'triggered' || alert.currentLowestPrice <= alert.targetPrice;

          return (
            <div
              key={alert.id}
              className={`p-5 rounded-2xl sm:rounded-3xl border transition-all shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-5 ${
                isTriggered
                  ? 'bg-gradient-to-r from-[#C8F902]/[0.08] via-[#0D1017] to-[#0A0C12] border-[#C8F902]/50 shadow-glow-lime'
                  : 'trading-card hover:border-white/[0.15]'
              }`}
            >
              {/* Product Info & Status */}
              <div className="flex items-start gap-4">
                <img
                  src={alert.productImage}
                  alt={alert.productTitle}
                  className="w-16 h-16 object-contain rounded-xl bg-[#06080C] p-2 border border-white/[0.06] flex-shrink-0"
                />

                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap font-mono">
                    <span
                      className={`text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full flex items-center gap-1 ${
                        isTriggered
                          ? 'bg-[#C8F902] text-[#08090C] shadow-glow-lime'
                          : 'bg-[#141824] text-slate-300 border border-white/[0.1]'
                      }`}
                    >
                      {isTriggered ? (
                        <>
                          <CheckCircle2 className="w-3 h-3 text-[#08090C]" />
                          TARGET REACHED! DEAL LIVE
                        </>
                      ) : (
                        <>
                          <Clock className="w-3 h-3 text-[#C8F902]" />
                          ACTIVE POLLING
                        </>
                      )}
                    </span>

                    <span className="text-[10px] text-slate-500">
                      Created {formatRelativeTime(alert.createdAt)}
                    </span>
                  </div>

                  <h3 className="text-sm sm:text-base font-bold text-white tracking-tight line-clamp-1">
                    {alert.productTitle}
                  </h3>

                  <div className="flex items-center gap-3 text-xs pt-0.5 font-mono">
                    <span className="text-slate-400">
                      Target: <strong className="text-white font-bold">{formatCurrency(alert.targetPrice)}</strong>
                    </span>
                    <span className="text-slate-600">•</span>
                    <span className="text-slate-400">
                      Current Low: <strong className={isTriggered ? 'text-[#C8F902] font-black' : 'text-slate-200'}>
                        {formatCurrency(alert.currentLowestPrice)}
                      </strong>
                    </span>
                    <span className="text-slate-600">•</span>
                    <span className="text-slate-400">
                      On <strong className="text-white">{vendor.name}</strong>
                    </span>
                  </div>

                  {/* Channels indicator */}
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 pt-1 font-mono">
                    <span>DISPATCH:</span>
                    {alert.notifyEmail && (
                      <span className="flex items-center gap-1 text-slate-300 bg-[#06080C] px-2 py-0.5 rounded border border-white/[0.06]">
                        <Mail className="w-3 h-3 text-[#C8F902]" />
                        {alert.emailAddress}
                      </span>
                    )}
                    {alert.notifyPush && (
                      <span className="flex items-center gap-1 text-slate-300 bg-[#06080C] px-2 py-0.5 rounded border border-white/[0.06]">
                        <Smartphone className="w-3 h-3 text-[#C8F902]" />
                        Browser Push
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2.5 self-end md:self-center font-mono">
                {/* Simulation button to test triggering the price alert */}
                <button
                  onClick={() => onSimulatePriceDrop(alert.id)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#C8F902]/10 hover:bg-[#C8F902]/20 text-[#C8F902] border border-[#C8F902]/30 transition-colors"
                  title="Simulate price falling below target threshold"
                >
                  <Zap className="w-3.5 h-3.5 text-[#C8F902]" />
                  <span>Simulate Trigger</span>
                </button>

                <button
                  onClick={() => onDeleteAlert(alert.id)}
                  className="p-2.5 rounded-xl text-slate-400 hover:text-[#FF3B30] hover:bg-[#FF3B30]/10 border border-white/[0.06] hover:border-[#FF3B30]/30 transition-all"
                  title="Remove alert"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
