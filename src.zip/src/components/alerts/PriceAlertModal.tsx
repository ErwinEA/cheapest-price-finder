import React, { useState } from 'react';
import { PriceAlert, Product } from '../../types';
import { formatCurrency, VENDORS } from '../../utils/formatters';
import {
  Bell,
  X,
  Mail,
  Smartphone,
  ShieldAlert
} from 'lucide-react';

interface PriceAlertModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onSaveAlert: (alertData: Omit<PriceAlert, 'id' | 'createdAt' | 'status' | 'lastChecked'>) => void;
  userEmail?: string;
}

export const PriceAlertModal: React.FC<PriceAlertModalProps> = ({
  product,
  isOpen,
  onClose,
  onSaveAlert,
  userEmail = 'user@example.com'
}) => {
  if (!isOpen || !product) return null;

  const currentLowest = product.cheapestPrice;
  const [targetPrice, setTargetPrice] = useState<number>(Math.floor(currentLowest * 0.9)); // default 10% below
  const [notifyEmail, setNotifyEmail] = useState(true);
  const [emailAddress, setEmailAddress] = useState(userEmail);
  const [notifyPush, setNotifyPush] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const handleQuickPercent = (discount: number) => {
    setTargetPrice(Math.floor(currentLowest * (1 - discount / 100)));
    setError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (targetPrice <= 0) {
      setError('Please enter a valid target price greater than ₹0.');
      return;
    }
    if (targetPrice >= currentLowest) {
      setError(`Target price must be lower than the current lowest price (${formatCurrency(currentLowest)}).`);
      return;
    }
    if (notifyEmail && (!emailAddress || !emailAddress.includes('@'))) {
      setError('Please enter a valid email address for notifications.');
      return;
    }
    if (!notifyEmail && !notifyPush) {
      setError('Please select at least one notification method (Email or Push).');
      return;
    }

    onSaveAlert({
      productId: product.id,
      productTitle: product.title,
      productImage: product.imageUrl,
      targetPrice,
      currentLowestPrice: currentLowest,
      cheapestVendor: product.cheapestVendor,
      notifyEmail,
      emailAddress: emailAddress.trim(),
      notifyPush
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="trading-card rounded-3xl w-full max-w-lg p-6 sm:p-7 shadow-2xl relative border-white/[0.12]">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="p-2.5 rounded-2xl bg-[#C8F902]/10 border border-[#C8F902]/20 text-[#C8F902]">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white tracking-tight uppercase font-mono">Set Target Price Trigger</h3>
            <p className="text-xs text-slate-400">Automated notification triggered when the lowest market price dips</p>
          </div>
        </div>

        {/* Selected Product Preview */}
        <div className="p-4 rounded-2xl bg-[#06080C] border border-white/[0.08] flex items-center gap-3.5 mb-5">
          <img
            src={product.imageUrl}
            alt={product.title}
            className="w-14 h-14 object-contain rounded-xl bg-[#0D1017] p-1.5 flex-shrink-0 border border-white/[0.06]"
          />
          <div className="min-w-0 font-mono">
            <h4 className="text-xs font-bold text-white truncate font-sans">{product.title}</h4>
            <div className="flex items-center gap-2 mt-1 text-xs">
              <span className="text-slate-400 text-[11px]">Current Lowest:</span>
              <strong className="text-[#C8F902] font-black">
                {formatCurrency(currentLowest)}
              </strong>
              <span className="text-[10px] text-slate-500">({VENDORS[product.cheapestVendor].name})</span>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Target Price Input */}
          <div>
            <label className="text-[11px] font-bold text-slate-300 block mb-1.5 uppercase tracking-wider font-mono">
              Target Execution Price (₹)
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-mono font-bold">
                ₹
              </span>
              <input
                type="number"
                min="1"
                max={currentLowest - 1}
                value={targetPrice}
                onChange={(e) => {
                  setTargetPrice(Number(e.target.value));
                  setError(null);
                }}
                className="w-full pl-8 pr-4 py-2.5 rounded-xl bg-[#06080C] border border-white/[0.12] text-white font-mono font-black text-lg focus:outline-none focus:border-[#C8F902] focus:ring-2 focus:ring-[#C8F902]/20"
              />
            </div>

            {/* Quick Percentage Presets */}
            <div className="flex items-center gap-2 mt-2 font-mono">
              <span className="text-[10px] text-slate-400">QUICK SPREAD:</span>
              {[5, 10, 15, 20].map((pct) => (
                <button
                  key={pct}
                  type="button"
                  onClick={() => handleQuickPercent(pct)}
                  className="px-2.5 py-0.5 rounded-md text-[10px] font-bold bg-[#141824] hover:bg-[#1f2636] text-[#C8F902] border border-[#C8F902]/20 transition-colors"
                >
                  -{pct}%
                </button>
              ))}
            </div>
          </div>

          {/* Notification Channels */}
          <div className="pt-3 border-t border-white/[0.08] space-y-3 font-mono">
            <label className="text-[11px] font-bold text-slate-300 block uppercase tracking-wider">
              Notification Channels
            </label>

            {/* Email notification */}
            <div className="space-y-2">
              <label className="flex items-center justify-between text-xs text-slate-200 cursor-pointer">
                <span className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-[#C8F902]" />
                  <span>Email Dispatch</span>
                </span>
                <input
                  type="checkbox"
                  checked={notifyEmail}
                  onChange={(e) => setNotifyEmail(e.target.checked)}
                  className="rounded border-slate-700 text-[#C8F902] focus:ring-0"
                />
              </label>

              {notifyEmail && (
                <input
                  type="email"
                  value={emailAddress}
                  onChange={(e) => setEmailAddress(e.target.value)}
                  placeholder="trader@example.com"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-[#06080C] border border-white/[0.08] text-white font-mono focus:outline-none focus:border-[#C8F902]"
                />
              )}
            </div>

            {/* Browser push notification */}
            <label className="flex items-center justify-between text-xs text-slate-200 cursor-pointer">
              <span className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-[#C8F902]" />
                <span>Real-Time Web Push & Browser Alert</span>
              </span>
              <input
                type="checkbox"
                checked={notifyPush}
                onChange={(e) => setNotifyPush(e.target.checked)}
                className="rounded border-slate-700 text-[#C8F902] focus:ring-0"
              />
            </label>
          </div>

          {/* Error notice */}
          {error && (
            <div className="text-xs text-[#FF3B30] flex items-center gap-1.5 p-3 rounded-xl bg-[#FF3B30]/10 border border-[#FF3B30]/30 font-mono">
              <ShieldAlert className="w-4 h-4 text-[#FF3B30] flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/[0.08]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-mono font-semibold text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl text-xs font-mono font-bold btn-lime flex items-center gap-1.5"
            >
              <Bell className="w-3.5 h-3.5" />
              <span>Activate Trigger</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
