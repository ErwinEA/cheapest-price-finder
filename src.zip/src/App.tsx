import React, { useState, useEffect, useCallback } from 'react';
import {
  LockoutState,
  PriceAlert,
  Product,
  ScrapingJob,
  ScrapingLog,
  SearchFilters,
  SearchHistoryItem,
  SiteSelectorConfig,
  User,
  VendorId
} from './types';
import { api } from './services/api';
import { ToastProvider, useToast } from './components/common/Toast';
import { Navbar } from './components/layout/Navbar';
import { SearchSection } from './components/search/SearchSection';
import { ProductCard } from './components/comparison/ProductCard';
import { SearchHistory } from './components/history/SearchHistory';
import { PriceAlerts } from './components/alerts/PriceAlerts';
import { PriceAlertModal } from './components/alerts/PriceAlertModal';
import { AdminPanel } from './components/admin/AdminPanel';
import { AuthModal } from './components/auth/AuthModal';
import { HelpGuide } from './components/common/HelpGuide';
import { ShoppingBag, Tag } from 'lucide-react';

const DEFAULT_FILTERS: SearchFilters = {
  query: 'iPhone',
  category: 'All',
  brands: [],
  minPrice: 0,
  maxPrice: 150000,
  minRating: 0,
  vendors: ['amazon', 'flipkart', 'bigbasket'],
  inStockOnly: false,
  sortBy: 'price_asc'
};

const MainAppContent: React.FC = () => {
  const toast = useToast();

  // Navigation tab
  const [currentTab, setCurrentTab] = useState<'search' | 'history' | 'alerts' | 'admin'>('search');

  // User & Auth State
  const [currentUser, setCurrentUser] = useState<User | null>(() => api.auth.getCurrentUser());
  const [lockoutState, setLockoutState] = useState<LockoutState>(() => api.auth.getLockoutState());
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Search & Catalog State
  const [filters, setFilters] = useState<SearchFilters>(DEFAULT_FILTERS);
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [sanitizationNotice, setSanitizationNotice] = useState<string | undefined>(undefined);

  // History & Alerts State
  const [history, setHistory] = useState<SearchHistoryItem[]>([]);
  const [alerts, setAlerts] = useState<PriceAlert[]>([]);
  const [selectedProductForAlert, setSelectedProductForAlert] = useState<Product | null>(null);
  const [isAlertModalOpen, setIsAlertModalOpen] = useState(false);

  // Admin Engine State
  const [jobs, setJobs] = useState<ScrapingJob[]>([]);
  const [logs, setLogs] = useState<ScrapingLog[]>([]);
  const [siteConfigs, setSiteConfigs] = useState<SiteSelectorConfig[]>([]);

  // Usability & Help Modal
  const [isHelpGuideOpen, setIsHelpGuideOpen] = useState(false);

  // Initial Data Fetch
  const loadInitialData = useCallback(async () => {
    try {
      const [allHist, allAlerts, allJobs, allLogs, allConfigs] = await Promise.all([
        api.history.getAll(),
        api.alerts.getAll(),
        api.admin.getScrapingJobs(),
        api.admin.getLogs(),
        api.admin.getSiteConfigs()
      ]);

      setHistory(allHist);
      setAlerts(allAlerts);
      setJobs(allJobs);
      setLogs(allLogs);
      setSiteConfigs(allConfigs);

      // Perform initial search
      handleSearch(DEFAULT_FILTERS, false);
    } catch (err: any) {
      toast.error('Initialization error', err.message);
    }
  }, []);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  // Execute Search
  const handleSearch = async (searchFilters: SearchFilters, notifyOnThreat = true) => {
    setIsSearching(true);
    setSanitizationNotice(undefined);

    try {
      const res = await api.products.search(searchFilters);
      setSearchResults(res.products);
      setFilters(searchFilters);

      if (res.sanitizationNotice) {
        setSanitizationNotice(res.sanitizationNotice);
        if (notifyOnThreat) {
          toast.warning('Input Sanitized', res.sanitizationNotice);
        }
      }

      // Refresh history list
      const updatedHistory = await api.history.getAll();
      setHistory(updatedHistory);
    } catch (err: any) {
      toast.error('Search Notice', err.message);
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  // Repeat Search from History
  const handleRepeatSearch = (query: string) => {
    const updatedFilters: SearchFilters = {
      ...filters,
      query
    };
    setFilters(updatedFilters);
    setCurrentTab('search');
    handleSearch(updatedFilters);
    toast.info('Repeat Search Executed', `Loaded price comparisons for "${query}"`);
  };

  // Delete single history item
  const handleDeleteHistoryItem = async (id: string) => {
    await api.history.delete(id);
    setHistory(prev => prev.filter(h => h.id !== id));
    toast.info('History item deleted');
  };

  // Clear all history
  const handleClearHistory = async () => {
    await api.history.clear();
    setHistory([]);
    toast.success('Search history cleared');
  };

  // Set Price Alert Modal Trigger
  const handleOpenAlertModal = (product: Product) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      toast.info('Authentication Required', 'Please sign in to configure automated price drop alerts.');
      return;
    }
    setSelectedProductForAlert(product);
    setIsAlertModalOpen(true);
  };

  // Save new Price Alert
  const handleSaveAlert = async (alertData: any) => {
    try {
      const newAlert = await api.alerts.create(alertData);
      setAlerts(prev => [newAlert, ...prev]);
      toast.success(
        'Price Alert Activated',
        `Tracking ${alertData.productTitle} for target ₹${alertData.targetPrice.toLocaleString('en-IN')}`
      );
    } catch (err: any) {
      toast.error('Unable to set alert', err.message);
    }
  };

  // Delete Alert
  const handleDeleteAlert = async (id: string) => {
    await api.alerts.delete(id);
    setAlerts(prev => prev.filter(a => a.id !== id));
    toast.info('Price alert deleted');
  };

  // Simulate Price Drop on Alert
  const handleSimulatePriceDrop = async (id: string) => {
    const updated = await api.alerts.simulateTrigger(id);
    if (updated) {
      setAlerts(prev => prev.map(a => a.id === id ? updated : a));
      toast.success(
        '🎉 Price Alert Triggered!',
        `Price dropped to ₹${updated.currentLowestPrice.toLocaleString('en-IN')} on ${updated.cheapestVendor}! Automated notification sent.`
      );
    }
  };

  // Auth: Login
  const handleLogin = async (email: string, pass: string) => {
    const result = await api.auth.login(email, pass);
    setCurrentUser(result.user);
    setLockoutState(result.lockout);
    toast.success('Signed In Successfully', `Welcome back, ${result.user.name}`);
  };

  // Auth: Register
  const handleRegister = async (name: string, email: string, pass: string, role: 'user' | 'admin' = 'user') => {
    const newUser = await api.auth.register(name, email, pass, role);
    setCurrentUser(newUser);
    setLockoutState(api.auth.getLockoutState());
    toast.success('Account Created', `Welcome to DealPulse, ${newUser.name}`);
  };

  // Auth: Logout
  const handleLogout = async () => {
    await api.auth.logout();
    setCurrentUser(null);
    toast.info('Signed out successfully');
  };

  // Fast Role Switcher (for immediate reviewer testing)
  const handleFastRoleToggle = () => {
    if (!currentUser) return;
    const nextRole: 'user' | 'admin' = currentUser.role === 'admin' ? 'user' : 'admin';
    const updatedUser: User = {
      ...currentUser,
      role: nextRole
    };
    setCurrentUser(updatedUser);
    localStorage.setItem('cpf_current_user', JSON.stringify(updatedUser));
    toast.info(
      'Role Switched',
      `You are now acting as: ${nextRole === 'admin' ? 'Administrator' : 'Standard User'}`
    );
  };

  // Lockout Simulator
  const handleSimulateLockout = () => {
    const locked = api.auth.simulateFiveFailedAttempts();
    setLockoutState(locked);
    toast.error('Account Locked (5 Failed Attempts)', 'Lockout enforced for 60 seconds.');
  };

  // Reset Lockout
  const handleResetLockout = () => {
    const reset = api.auth.resetLockout();
    setLockoutState(reset);
    toast.info('Lockout Reset', 'Login counter restored to 0.');
  };

  // Admin: Trigger Scrape
  const handleTriggerScrape = async (vendor: VendorId) => {
    try {
      const runningJob = await api.admin.triggerScrape(vendor);
      setJobs(prev => prev.map(j => j.vendor === vendor ? runningJob : j));
      const freshLogs = await api.admin.getLogs();
      setLogs(freshLogs);
      toast.info('Scraper Worker Started', `Spun up crawler pool for ${runningJob.vendorName}`);

      // Auto-complete simulation after 2.5 seconds
      setTimeout(async () => {
        const simulatedCount = Math.floor(Math.random() * 500) + 1200;
        await api.admin.completeScrapeSimulation(runningJob.id, simulatedCount);
        const updatedJobs = await api.admin.getScrapingJobs();
        const updatedLogs = await api.admin.getLogs();
        setJobs(updatedJobs);
        setLogs(updatedLogs);
        toast.success(
          'Scrape Completed',
          `Successfully ingested ${simulatedCount} new price points from ${runningJob.vendorName}`
        );
      }, 2500);
    } catch (err: any) {
      toast.error('Failed to trigger scraper', err.message);
    }
  };

  // Admin: Update Selector Config
  const handleUpdateConfig = async (config: SiteSelectorConfig) => {
    try {
      const updated = await api.admin.updateSiteConfig(config);
      setSiteConfigs(prev => prev.map(c => c.vendor === updated.vendor ? updated : c));
      const updatedLogs = await api.admin.getLogs();
      setLogs(updatedLogs);
      toast.success(
        'Selectors Saved',
        `Live CSS extraction rules for ${updated.vendorName} recompiled successfully.`
      );
    } catch (err: any) {
      toast.error('Failed to update config', err.message);
    }
  };

  // Admin: Clear Logs
  const handleClearLogs = async () => {
    await api.admin.clearLogs();
    setLogs([]);
    toast.info('Scraper logs cleared');
  };

  const activeAlertsCount = alerts.filter(a => a.status === 'active' || a.status === 'triggered').length;

  return (
    <div className="min-h-screen bg-[#08090C] text-slate-100 flex flex-col selection:bg-[#C8F902]/30 selection:text-[#C8F902]">
      {/* Top Navigation */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onLogout={handleLogout}
        onFastRoleToggle={handleFastRoleToggle}
        activeAlertsCount={activeAlertsCount}
        onOpenFlowGuide={() => setIsHelpGuideOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* VIEW 1: SEARCH & COMPARISON */}
        {currentTab === 'search' && (
          <div className="space-y-8 animate-fadeIn">
            {/* Hero Heading - Trading Platform Aesthetic */}
            <div className="text-center max-w-3xl mx-auto space-y-3">
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#0D1017] border border-white/[0.08] text-[11px] font-mono text-slate-300">
                <span className="w-2 h-2 rounded-full bg-[#C8F902] neon-dot"></span>
                <span>Sub-Second Cross-Marketplace Match Engine</span>
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight uppercase font-mono">
                Scan The Lowest Bid. <span className="text-[#C8F902]">Never Overpay.</span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto leading-relaxed">
                Algorithmic product matching across Amazon, Flipkart, & BigBasket. Spot market spreads, 30-day volatility charts, and direct checkout routes.
              </p>
            </div>

            {/* Search Bar & Filter Accordion */}
            <div className="max-w-4xl mx-auto">
              <SearchSection
                filters={filters}
                onSearch={(updated) => handleSearch(updated)}
                isLoading={isSearching}
                sanitizationNotice={sanitizationNotice}
                totalResultsCount={searchResults.length}
              />
            </div>

            {/* Comparison Results List */}
            <div className="max-w-4xl mx-auto space-y-6">
              {isSearching ? (
                <div className="p-12 text-center space-y-3 font-mono">
                  <div className="w-10 h-10 border-4 border-[#C8F902]/20 border-t-[#C8F902] rounded-full animate-spin mx-auto"></div>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">
                    Querying Scraper Pool Nodes (Amazon • Flipkart • BigBasket)...
                  </p>
                </div>
              ) : searchResults.length > 0 ? (
                searchResults.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onSetAlert={handleOpenAlertModal}
                  />
                ))
              ) : (
                <div className="trading-card rounded-3xl p-12 text-center max-w-md mx-auto shadow-2xl">
                  <div className="w-14 h-14 mx-auto rounded-2xl bg-[#C8F902]/10 border border-[#C8F902]/20 flex items-center justify-center text-[#C8F902] mb-4">
                    <ShoppingBag className="w-7 h-7" />
                  </div>
                  <h3 className="text-base font-bold text-white uppercase tracking-wider font-mono">No Products Matched</h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Try searching for popular items like "iPhone 15", "Aashirvaad Atta", "Sony XM5", or adjusting price filters.
                  </p>
                  <button
                    onClick={() => handleSearch(DEFAULT_FILTERS)}
                    className="mt-4 px-4 py-2 rounded-xl text-xs font-mono font-bold btn-lime"
                  >
                    Reset Search Query
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* VIEW 2: SEARCH HISTORY */}
        {currentTab === 'history' && (
          <div className="animate-fadeIn">
            <SearchHistory
              history={history}
              onRepeatSearch={handleRepeatSearch}
              onDeleteItem={handleDeleteHistoryItem}
              onClearAll={handleClearHistory}
            />
          </div>
        )}

        {/* VIEW 3: PRICE ALERTS */}
        {currentTab === 'alerts' && (
          <div className="animate-fadeIn">
            <PriceAlerts
              alerts={alerts}
              onDeleteAlert={handleDeleteAlert}
              onSimulatePriceDrop={handleSimulatePriceDrop}
              onOpenSearch={() => setCurrentTab('search')}
            />
          </div>
        )}

        {/* VIEW 4: ADMIN PANEL */}
        {currentTab === 'admin' && (
          <div className="animate-fadeIn">
            <AdminPanel
              currentUser={currentUser}
              onSwitchToAdmin={() => {
                const adminUser: User = {
                  id: 'usr-admin-01',
                  email: 'admin@dealpulse.com',
                  name: 'Admin Supervisor',
                  role: 'admin',
                  createdAt: new Date().toISOString()
                };
                setCurrentUser(adminUser);
                localStorage.setItem('cpf_current_user', JSON.stringify(adminUser));
                toast.success('Admin Session Initialized', 'Granted full crawler control permissions.');
              }}
              jobs={jobs}
              logs={logs}
              configs={siteConfigs}
              onTriggerScrape={handleTriggerScrape}
              onUpdateConfig={handleUpdateConfig}
              onClearLogs={handleClearLogs}
            />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/[0.08] bg-[#050608] py-8 px-4 text-center text-xs text-slate-500 mt-12 font-mono">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-[#C8F902]" />
            <span className="font-bold text-slate-300">DEALPULSE // PRODUCT ARBITRAGE TERMINAL</span>
            <span className="text-slate-600">• Multi-Node Price Aggregator</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>Chrome • Edge • Firefox Verified</span>
            <span className="text-slate-700">•</span>
            <button
              onClick={() => setIsHelpGuideOpen(true)}
              className="text-[#C8F902] hover:underline font-bold"
            >
              Usability & Security Specs
            </button>
          </div>
        </div>
      </footer>

      {/* MODALS */}
      {/* 1. Auth Modal (Sign In / Register / 5-Failed-Attempts Lockout) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
        onRegister={handleRegister}
        lockoutState={lockoutState}
        onSimulateLockout={handleSimulateLockout}
        onResetLockout={handleResetLockout}
      />

      {/* 2. Price Alert Modal */}
      <PriceAlertModal
        product={selectedProductForAlert}
        isOpen={isAlertModalOpen}
        onClose={() => {
          setIsAlertModalOpen(false);
          setSelectedProductForAlert(null);
        }}
        onSaveAlert={handleSaveAlert}
        userEmail={currentUser?.email || 'user@example.com'}
      />

      {/* 3. Usability & Help Guide */}
      <HelpGuide
        isOpen={isHelpGuideOpen}
        onClose={() => setIsHelpGuideOpen(false)}
      />
    </div>
  );
};

export function App() {
  return (
    <ToastProvider>
      <MainAppContent />
    </ToastProvider>
  );
}

export default App;
